<?php
session_start();
include 'config/database.php';

// Set zona waktu
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SESSION['role'] != 'guru') {
    echo "<div class='alert alert-danger'>Akses ditolak. Hanya guru yang bisa melihat laporan.</div>";
    echo "<a href='dashboard.php'>Kembali ke Dashboard</a>";
    exit();
}

// Ambil parameter filter
$filter_tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$filter_kelas = isset($_GET['kelas']) ? $_GET['kelas'] : '';
$today = date('Y-m-d');

// Ambil daftar kelas unik untuk dropdown
$query_kelas = "SELECT DISTINCT kelas FROM siswa ORDER BY kelas";
$result_kelas = mysqli_query($conn, $query_kelas);
$kelas_list = [];
while ($row = mysqli_fetch_assoc($result_kelas)) {
    $kelas_list[] = $row['kelas'];
}

// Build query dengan filter
$where_conditions = [];
if (!empty($filter_tanggal)) {
    $where_conditions[] = "a.tanggal = '$filter_tanggal'";
}
if (!empty($filter_kelas)) {
    $where_conditions[] = "s.kelas = '$filter_kelas'";
}

$where_clause = !empty($where_conditions) ? "WHERE " . implode(" AND ", $where_conditions) : "";

$query = "SELECT a.tanggal, a.waktu, a.waktu_pulang, a.status, a.status_pulang, a.keterangan, 
                 a.status_verifikasi, a.bukti_file, a.telat, a.kategori_telat, a.poin, s.nama, s.kelas 
          FROM absensi a 
          JOIN siswa s ON a.siswa_id = s.id 
          $where_clause
          ORDER BY a.tanggal DESC, a.waktu DESC";

$result = mysqli_query($conn, $query);

// Hitung statistik
$total_hadir = 0;
$total_izin = 0;
$total_sakit = 0;
$total_alfa = 0;
$total_sudah_pulang = 0;
$total_menit_telat = 0;
$total_poin = 0;

$data_temp = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data_temp[] = $row;
    switch ($row['status']) {
        case 'hadir': $total_hadir++; break;
        case 'izin': $total_izin++; break;
        case 'sakit': $total_sakit++; break;
        case 'alfa': $total_alfa++; break;
    }
    if (isset($row['status_pulang']) && $row['status_pulang'] == 'sudah') {
        $total_sudah_pulang++;
    }
    if (isset($row['telat']) && $row['telat'] > 0) {
        $total_menit_telat += $row['telat'];
        $total_poin += $row['poin'];
    }
}
$total_absensi = $total_hadir + $total_izin + $total_sakit + $total_alfa;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Absensi - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/laporan.css">
</head>
<body>
    <div class="laporan-card">
        <!-- Header -->
        <div class="card-header-gradient text-white p-4">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h2 class="mb-1 fw-bold">
                        <i class="bi bi-clipboard-data-fill me-2"></i> Laporan Absensi
                    </h2>
                    <p class="mb-0 opacity-75">Data kehadiran siswa lengkap dengan waktu masuk, pulang & keterlambatan</p>
                </div>
                <div class="mt-3 mt-sm-0">
                    <button onclick="window.print()" class="btn btn-print me-2">
                        <i class="bi bi-printer"></i> Cetak
                    </button>
                    <a href="dashboard.php" class="btn btn-outline-light">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>

        <div class="card-body p-4" style="background: #f8fafc;">
            <!-- Filter Box -->
            <div class="filter-box">
                <form method="get" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-muted">
                            <i class="bi bi-calendar3 me-1"></i> Filter Tanggal
                        </label>
                        <input type="date" name="tanggal" class="form-control rounded-pill" value="<?= $filter_tanggal ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold text-muted">
                            <i class="bi bi-building me-1"></i> Filter Kelas
                        </label>
                        <select name="kelas" class="form-select rounded-pill">
                            <option value="">Semua Kelas</option>
                            <?php foreach ($kelas_list as $kelas): ?>
                                <option value="<?= htmlspecialchars($kelas) ?>" <?= $filter_kelas == $kelas ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($kelas) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary rounded-pill px-4">
                                <i class="bi bi-filter"></i> Filter
                            </button>
                            <?php if (!empty($filter_tanggal) || !empty($filter_kelas)): ?>
                                <a href="laporan.php" class="btn btn-secondary rounded-pill px-4">
                                    <i class="bi bi-eraser"></i> Reset
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Info Filter -->
            <div class="text-end mb-3">
                <span class="text-muted">
                    <i class="bi bi-info-circle"></i> 
                    <?php 
                    $filter_info = [];
                    if (!empty($filter_tanggal)) $filter_info[] = "Tanggal: " . date('d-m-Y', strtotime($filter_tanggal));
                    if (!empty($filter_kelas)) $filter_info[] = "Kelas: " . htmlspecialchars($filter_kelas);
                    if (empty($filter_info)) {
                        echo "Menampilkan semua riwayat absensi";
                    } else {
                        echo "Menampilkan laporan - " . implode(" | ", $filter_info);
                    }
                    ?>
                </span>
            </div>

            <!-- Statistik Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Absensi</p>
                                <p class="stat-value"><?= $total_absensi ?></p>
                            </div>
                            <div class="stat-icon" style="background: linear-gradient(135deg, #667eea20, #764ba220); color: #667eea;">
                                <i class="bi bi-people-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Hadir</p>
                                <p class="stat-value text-success"><?= $total_hadir ?></p>
                            </div>
                            <div class="stat-icon" style="background: #22c55e20; color: #22c55e;">
                                <i class="bi bi-check-circle-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Izin</p>
                                <p class="stat-value text-warning"><?= $total_izin ?></p>
                            </div>
                            <div class="stat-icon" style="background: #eab30820; color: #eab308;">
                                <i class="bi bi-envelope-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Sakit</p>
                                <p class="stat-value text-info"><?= $total_sakit ?></p>
                            </div>
                            <div class="stat-icon" style="background: #0ea5e920; color: #0ea5e9;">
                                <i class="bi bi-heart-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Alfa</p>
                                <p class="stat-value text-danger"><?= $total_alfa ?></p>
                            </div>
                            <div class="stat-icon" style="background: #ef444420; color: #ef4444;">
                                <i class="bi bi-x-circle-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Sudah Pulang</p>
                                <p class="stat-value text-primary"><?= $total_sudah_pulang ?></p>
                            </div>
                            <div class="stat-icon" style="background: #0ea5e920; color: #0ea5e9;">
                                <i class="bi bi-house-door-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Statistik Telat -->
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Menit Keterlambatan</p>
                                <p class="stat-value text-danger"><?= $total_menit_telat ?> menit</p>
                            </div>
                            <div class="stat-icon" style="background: #ef444420; color: #ef4444;">
                                <i class="bi bi-clock-history"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Poin Pelanggaran</p>
                                <p class="stat-value text-warning"><?= $total_poin ?> poin</p>
                            </div>
                            <div class="stat-icon" style="background: #eab30820; color: #eab308;">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabel Data -->
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-0">
                    <div class="p-3 border-bottom d-flex justify-content-between align-items-center flex-wrap">
                        <h5 class="mb-0 fw-semibold">
                            <i class="bi bi-table me-2 text-primary"></i> Detail Absensi
                        </h5>
                        <div class="search-box mt-2 mt-sm-0">
                            <i class="bi bi-search text-muted me-2"></i>
                            <input type="text" id="searchInput" placeholder="Cari nama siswa..." onkeyup="searchTable()">
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-custom mb-0" id="absensiTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th><i class="bi bi-calendar3 me-1"></i> Tanggal</th>
                                    <th><i class="bi bi-person me-1"></i> Nama Siswa</th>
                                    <th><i class="bi bi-building me-1"></i> Kelas</th>
                                    <th><i class="bi bi-check-circle me-1"></i> Status</th>
                                    <th><i class="bi bi-clock me-1"></i> Masuk</th>
                                    <th><i class="bi bi-clock-history me-1"></i> Telat</th>
                                    <th><i class="bi bi-hourglass-split me-1"></i> Pulang</th>
                                    <th><i class="bi bi-exclamation-triangle me-1"></i> Poin</th>
                                    <th><i class="bi bi-chat-text me-1"></i> Keterangan</th>
                                    <th><i class="bi bi-shield-check me-1"></i> Verifikasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($data_temp) > 0): ?>
                                    <?php $no = 1; ?>
                                    <?php foreach ($data_temp as $row): ?>
                                        <tr class="<?= ($row['telat'] ?? 0) > 30 ? 'table-danger' : (($row['telat'] ?? 0) > 0 ? 'table-warning' : '') ?>">
                                            <td class="text-center fw-medium"><?= $no++ ?></td>
                                            <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                                            <td class="fw-medium"><?= htmlspecialchars($row['nama']) ?> 
                                                <?php if (!empty($row['bukti_file'])): ?>
                                                    <i class="bi bi-paperclip text-muted" title="Ada bukti lampiran"></i>
                                                <?php endif; ?>
                                             </td>
                                            <td><?= htmlspecialchars($row['kelas']) ?></td>
                                            <td class="text-center">
                                                <?php if ($row['status'] == 'hadir'): ?>
                                                    <span class="badge-custom" style="background: #22c55e20; color: #22c55e;">
                                                        <i class="bi bi-check-circle-fill me-1"></i> Hadir
                                                    </span>
                                                <?php elseif ($row['status'] == 'izin'): ?>
                                                    <span class="badge-custom" style="background: #eab30820; color: #eab308;">
                                                        <i class="bi bi-envelope-fill me-1"></i> Izin
                                                    </span>
                                                <?php elseif ($row['status'] == 'sakit'): ?>
                                                    <span class="badge-custom" style="background: #0ea5e920; color: #0ea5e9;">
                                                        <i class="bi bi-heart-fill me-1"></i> Sakit
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge-custom" style="background: #ef444420; color: #ef4444;">
                                                        <i class="bi bi-x-circle-fill me-1"></i> Alfa
                                                    </span>
                                                <?php endif; ?>
                                             </td>
                                            <td class="text-center"><?= !empty($row['waktu']) ? substr($row['waktu'], 0, 5) . ' WIB' : '-' ?></td>
                                            <td class="text-center">
                                                <?php if (isset($row['telat']) && $row['telat'] > 0): ?>
                                                    <?php 
                                                    $telat = $row['telat'];
                                                    $jam = floor($telat / 60);
                                                    $menit = $telat % 60;
                                                    $telat_text = '';
                                                    if ($jam > 0) $telat_text .= $jam . ' jam ';
                                                    if ($menit > 0) $telat_text .= $menit . ' menit';
                                                    ?>
                                                    <span class="badge-telat-<?= $row['kategori_telat'] == 'Tepat Waktu' ? 'tepat' : ($row['kategori_telat'] == 'Telat Ringan' ? 'ringan' : ($row['kategori_telat'] == 'Telat Sedang' ? 'sedang' : 'berat')) ?>">
                                                        <?= $telat_text ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge-tepat">Tepat Waktu</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if (!empty($row['waktu_pulang'])): ?>
                                                    <span class="text-success"><?= substr($row['waktu_pulang'], 0, 5) ?> WIB</span>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if (isset($row['poin']) && $row['poin'] > 0): ?>
                                                    <span class="badge bg-danger rounded-pill"><?= $row['poin'] ?></span>
                                                <?php else: ?>
                                                    <span class="text-muted">0</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="keterangan-cell" title="<?= htmlspecialchars($row['keterangan'] ?? '') ?>">
                                                <?= !empty($row['keterangan']) ? htmlspecialchars($row['keterangan']) : '-' ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if ($row['status'] == 'izin' || $row['status'] == 'sakit'): ?>
                                                    <?php if (($row['status_verifikasi'] ?? 'pending') == 'pending'): ?>
                                                        <span class="verif-pending">⏳ Menunggu</span>
                                                    <?php elseif (($row['status_verifikasi'] ?? '') == 'disetujui'): ?>
                                                        <span class="verif-disetujui">✅ Disetujui</span>
                                                    <?php else: ?>
                                                        <span class="verif-ditolak">❌ Ditolak</span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span class="text-muted">-</span>
                                                <?php endif; ?>
                                             </td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="11" class="text-center py-5">
                                            <i class="bi bi-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
                                            <p class="mt-3 text-muted">Belum ada data absensi</p>
                                            <small>Silakan lakukan scan QR Code untuk mengisi data</small>
                                         </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Footer -->
            <div class="mt-4 text-center text-muted">
                <small>
                    <i class="bi bi-printer"></i> Laporan dihasilkan: <?= date('d-m-Y H:i:s') ?>
                </small>
            </div>
        </div>
    </div>

    <script>
        function searchTable() {
            let input = document.getElementById('searchInput');
            let filter = input.value.toLowerCase();
            let table = document.getElementById('absensiTable');
            let tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                let td = tr[i].getElementsByTagName('td')[2];
                if (td) {
                    let textValue = td.textContent || td.innerText;
                    if (textValue.toLowerCase().indexOf(filter) > -1) {
                        tr[i].style.display = '';
                    } else {
                        tr[i].style.display = 'none';
                    }
                }
            }
        }
    </script>
</body>
</html>