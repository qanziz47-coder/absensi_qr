<?php
session_start();
include 'config/database.php';

// Cek login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// HANYA DEVELOPER YANG BISA AKSES
if ($_SESSION['role'] != 'developer') {
    echo "<div class='alert alert-danger text-center p-5'>";
    echo "<i class='bi bi-shield-lock-fill' style='font-size: 64px;'></i>";
    echo "<h2 class='mt-3'>Akses Ditolak!</h2>";
    echo "<p>Halaman ini hanya dapat diakses oleh <strong>Developer</strong>.</p>";
    echo "<a href='dashboard.php' class='btn btn-primary'>Kembali ke Dashboard</a>";
    echo "</div>";
    exit();
}

// Ambil pengaturan
$wa_enabled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_enabled'"))['value_setting'] ?? 'false';
$wa_api_key = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_api_key'"))['value_setting'] ?? '';
$wa_group_id = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_group_id'"))['value_setting'] ?? '';

// Proses simpan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $wa_enabled_new = isset($_POST['wa_enabled']) ? 'true' : 'false';
    $wa_api_key_new = $_POST['wa_api_key'];
    $wa_group_id_new = $_POST['wa_group_id'];
    
    mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$wa_enabled_new' WHERE key_setting = 'wa_enabled'");
    mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$wa_api_key_new' WHERE key_setting = 'wa_api_key'");
    mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$wa_group_id_new' WHERE key_setting = 'wa_group_id'");
    
    $message = "Pengaturan berhasil disimpan!";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer - Pengaturan WhatsApp</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/ortu_siswa.css">
</head>
<body>
    <div class="dev-card">
        <div class="dev-header text-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1 fw-bold">
                        <i class="bi bi-shield-lock-fill me-2"></i> Developer Panel
                    </h4>
                    <p class="mb-0 opacity-75">Pengaturan WhatsApp Gateway</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <?php if (isset($message)): ?>
                <div class="alert alert-success rounded-4">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $message ?>
                </div>
            <?php endif; ?>
            
            <div class="alert alert-info rounded-4">
                <i class="bi bi-info-circle-fill me-2"></i>
                Halaman ini hanya dapat diakses oleh <strong>Developer</strong>. Guru biasa tidak dapat mengubah pengaturan ini.
            </div>
            
            <form method="post">
                <div class="mb-3">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" name="wa_enabled" id="wa_enabled" <?= $wa_enabled == 'true' ? 'checked' : '' ?>>
                        <label class="form-check-label fw-semibold" for="wa_enabled">
                            <i class="bi bi-whatsapp text-success"></i> Aktifkan Notifikasi WhatsApp
                        </label>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-semibold">
                        <i class="bi bi-key-fill"></i> API Key (Fonnte)
                    </label>
                    <input type="text" name="wa_api_key" class="form-control rounded-pill" 
                           value="<?= htmlspecialchars($wa_api_key) ?>" 
                           placeholder="Masukkan API Key dari Fonnte">
                    <small class="text-muted">Dapatkan dari dashboard Fonnte</small>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-semibold">
                        <i class="bi bi-people-fill"></i> ID Grup WhatsApp
                    </label>
                    <input type="text" name="wa_group_id" class="form-control rounded-pill" 
                           value="<?= htmlspecialchars($wa_group_id) ?>" 
                           placeholder="Contoh: 628123456789-1234567890@g.us">
                    <small class="text-muted">ID grup yang akan menerima notifikasi keterlambatan</small>
                </div>
                
                <button type="submit" class="btn btn-save text-white w-100 rounded-pill">
                    <i class="bi bi-save"></i> Simpan Pengaturan
                </button>
            </form>
            
            <hr class="my-4">
            
            <div class="text-center">
                <small class="text-muted">
                    <i class="bi bi-shield-check"></i> Hanya Developer yang memiliki akses ke halaman ini
                </small>
            </div>
        </div>
    </div>
</body>
</html>