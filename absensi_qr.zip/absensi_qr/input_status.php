<?php
session_start();
include 'config/database.php';

// Set zona waktu
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header("Location: index.php");
    exit();
}

$today = date('Y-m-d');

// Ambil daftar siswa yang BELUM absen hari ini
$query_belum = "SELECT s.id, s.nama, s.kelas 
                FROM siswa s 
                WHERE s.id NOT IN (
                    SELECT siswa_id FROM absensi WHERE tanggal = '$today'
                )
                ORDER BY s.nama ASC";
$result_belum = mysqli_query($conn, $query_belum);
$siswa_belum_absen = [];
while ($row = mysqli_fetch_assoc($result_belum)) {
    $siswa_belum_absen[] = $row;
}

// Ambil daftar siswa yang SUDAH absen hari ini (untuk edit) - DENGAN BUKTI
$query_sudah = "SELECT a.id, a.status, a.keterangan, a.bukti_file, a.status_verifikasi, 
                       s.id as siswa_id, s.nama, s.kelas 
                FROM absensi a 
                JOIN siswa s ON a.siswa_id = s.id 
                WHERE a.tanggal = '$today'
                ORDER BY s.nama ASC";
$result_sudah = mysqli_query($conn, $query_sudah);
$siswa_sudah_absen = [];
while ($row = mysqli_fetch_assoc($result_sudah)) {
    $siswa_sudah_absen[] = $row;
}

// Proses update status (dengan verifikasi)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_status'])) {
    $absensi_id = $_POST['absensi_id'];
    $status = $_POST['status'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    $status_verifikasi = $_POST['status_verifikasi'] ?? 'pending';
    
    $update = "UPDATE absensi SET status = '$status', keterangan = '$keterangan', status_verifikasi = '$status_verifikasi' WHERE id = '$absensi_id'";
    if (mysqli_query($conn, $update)) {
        $success = "Status berhasil diupdate!";
        header("Refresh:0");
    } else {
        $error = "Gagal update: " . mysqli_error($conn);
    }
}

// Proses tambah absen manual (izin/sakit/alfa)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_absen'])) {
    $siswa_id = $_POST['siswa_id'];
    $status = $_POST['status'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    $waktu = date('H:i:s');
    
    $insert = "INSERT INTO absensi (siswa_id, tanggal, waktu, status, keterangan, status_verifikasi) 
               VALUES ('$siswa_id', '$today', '$waktu', '$status', '$keterangan', 'disetujui')";
    
    if (mysqli_query($conn, $insert)) {
        $success = "Absen $status berhasil ditambahkan!";
        header("Refresh:0");
    } else {
        $error = "Gagal menambah absen: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Status Absensi - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/input_status.css">
</head>
<body>
    <div class="page-card">
        <div class="card-header-custom text-white">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h4 class="mb-1 fw-bold"><i class="bi bi-pencil-square me-2"></i> Input Status Absensi</h4>
                    <p class="mb-0 opacity-75">Mengelola status kehadiran siswa (Hadir, Izin, Sakit, Alfa)</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill mt-2 mt-sm-0">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <?php if (isset($success)): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <div class="row">
                <!-- Kolom Kiri: Siswa yang sudah absen -->
                <div class="col-lg-6 mb-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-0 py-3">
                            <h5 class="mb-0 fw-semibold">
                                <i class="bi bi-check-circle text-success me-2"></i> 
                                Sudah Absen Hari Ini
                                <span class="badge bg-success ms-2"><?= count($siswa_sudah_absen) ?></span>
                            </h5>
                        </div>
                        <div class="card-body pt-0">
                            <?php if (count($siswa_sudah_absen) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Siswa</th>
                                                <th>Kelas</th>
                                                <th>Status</th>
                                                <th>Verifikasi</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1; foreach ($siswa_sudah_absen as $absen): ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td class="fw-medium"><?= htmlspecialchars($absen['nama']) ?> <?php if (!empty($absen['bukti_file'])): ?><i class="bi bi-paperclip text-muted" title="Ada bukti lampiran"></i><?php endif; ?></td>
                                                <td><?= htmlspecialchars($absen['kelas']) ?></td>
                                                <td>
                                                    <span class="status-badge status-<?= $absen['status'] ?>">
                                                        <i class="bi bi-<?= $absen['status'] == 'hadir' ? 'check-circle' : ($absen['status'] == 'izin' ? 'envelope' : ($absen['status'] == 'sakit' ? 'heart' : 'x-circle')) ?> me-1"></i>
                                                        <?= ucfirst($absen['status']) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php if ($absen['status'] == 'izin' || $absen['status'] == 'sakit'): ?>
                                                        <span class="status-badge verif-<?= $absen['status_verifikasi'] ?? 'pending' ?>">
                                                            <?php if (($absen['status_verifikasi'] ?? 'pending') == 'pending'): ?>
                                                                ⏳ Menunggu
                                                            <?php elseif (($absen['status_verifikasi'] ?? 'pending') == 'disetujui'): ?>
                                                                ✅ Disetujui
                                                            <?php else: ?>
                                                                ❌ Ditolak
                                                            <?php endif; ?>
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-outline-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#editModal<?= $absen['id'] ?>">
                                                        <i class="bi bi-pencil"></i> Edit
                                                    </button>
                                                </td>
                                            </tr>
                                            
                                            <!-- Modal Edit -->
                                            <div class="modal fade" id="editModal<?= $absen['id'] ?>" tabindex="-1">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content rounded-4">
                                                        <form method="post">
                                                            <div class="modal-header border-0">
                                                                <h5 class="modal-title fw-bold">Edit Status Absensi</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p class="mb-3">Siswa: <strong><?= htmlspecialchars($absen['nama']) ?></strong></p>
                                                                <input type="hidden" name="absensi_id" value="<?= $absen['id'] ?>">
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Status</label>
                                                                    <select name="status" class="form-select rounded-pill" required>
                                                                        <option value="hadir" <?= $absen['status'] == 'hadir' ? 'selected' : '' ?>>✅ Hadir</option>
                                                                        <option value="izin" <?= $absen['status'] == 'izin' ? 'selected' : '' ?>>📝 Izin</option>
                                                                        <option value="sakit" <?= $absen['status'] == 'sakit' ? 'selected' : '' ?>>🤒 Sakit</option>
                                                                        <option value="alfa" <?= $absen['status'] == 'alfa' ? 'selected' : '' ?>>❌ Alfa</option>
                                                                    </select>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Keterangan</label>
                                                                    <textarea name="keterangan" class="form-control rounded-3" rows="2" placeholder="Isi keterangan jika diperlukan..."><?= htmlspecialchars($absen['keterangan'] ?? '') ?></textarea>
                                                                </div>
                                                                <?php if (!empty($absen['bukti_file']) && file_exists($absen['bukti_file'])): ?>
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Bukti Upload</label><br>
                                                                    <a href="<?= $absen['bukti_file'] ?>" target="_blank" class="btn btn-sm btn-outline-info rounded-pill">
                                                                        <i class="bi bi-eye"></i> Lihat Bukti
                                                                    </a>
                                                                </div>
                                                                <?php endif; ?>
                                                                <?php if ($absen['status'] == 'izin' || $absen['status'] == 'sakit'): ?>
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Status Verifikasi</label>
                                                                    <select name="status_verifikasi" class="form-select rounded-pill">
                                                                        <option value="pending" <?= ($absen['status_verifikasi'] ?? 'pending') == 'pending' ? 'selected' : '' ?>>⏳ Menunggu Verifikasi</option>
                                                                        <option value="disetujui" <?= ($absen['status_verifikasi'] ?? '') == 'disetujui' ? 'selected' : '' ?>>✅ Disetujui</option>
                                                                        <option value="ditolak" <?= ($absen['status_verifikasi'] ?? '') == 'ditolak' ? 'selected' : '' ?>>❌ Ditolak</option>
                                                                    </select>
                                                                    <small class="text-muted">Verifikasi bukti yang diupload siswa</small>
                                                                </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="modal-footer border-0">
                                                                <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" name="update_status" class="btn btn-submit text-white rounded-pill">Simpan Perubahan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="bi bi-inbox" style="font-size: 48px;"></i>
                                    <p class="mt-2">Belum ada yang absen hari ini</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Kolom Kanan: Siswa yang belum absen -->
                <div class="col-lg-6 mb-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-0 py-3">
                            <h5 class="mb-0 fw-semibold">
                                <i class="bi bi-clock-history text-warning me-2"></i> 
                                Belum Absen Hari Ini
                                <span class="badge bg-warning text-dark ms-2"><?= count($siswa_belum_absen) ?></span>
                            </h5>
                        </div>
                        <div class="card-body pt-0">
                            <?php if (count($siswa_belum_absen) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Siswa</th>
                                                <th>Kelas</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no = 1; foreach ($siswa_belum_absen as $siswa): ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td class="fw-medium"><?= htmlspecialchars($siswa['nama']) ?></td>
                                                <td><?= htmlspecialchars($siswa['kelas']) ?></td>
                                                <td>
                                                    <button type="button" class="btn btn-sm btn-primary rounded-pill" data-bs-toggle="modal" data-bs-target="#addModal<?= $siswa['id'] ?>">
                                                        <i class="bi bi-plus-circle"></i> Tambah Absen
                                                    </button>
                                                </td>
                                            </tr>
                                            
                                            <!-- Modal Tambah Absen -->
                                            <div class="modal fade" id="addModal<?= $siswa['id'] ?>" tabindex="-1">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content rounded-4">
                                                        <form method="post">
                                                            <div class="modal-header border-0">
                                                                <h5 class="modal-title fw-bold">Tambah Absensi Manual</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <p class="mb-3">Siswa: <strong><?= htmlspecialchars($siswa['nama']) ?></strong></p>
                                                                <input type="hidden" name="siswa_id" value="<?= $siswa['id'] ?>">
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Status</label>
                                                                    <select name="status" class="form-select rounded-pill" required>
                                                                        <option value="izin">📝 Izin</option>
                                                                        <option value="sakit">🤒 Sakit</option>
                                                                        <option value="alfa">❌ Alfa</option>
                                                                    </select>
                                                                    <small class="text-muted">Untuk absen Hadir, silakan gunakan scan QR Code.</small>
                                                                </div>
                                                                <div class="mb-3">
                                                                    <label class="form-label fw-semibold">Keterangan</label>
                                                                    <textarea name="keterangan" class="form-control rounded-3" rows="2" placeholder="Isi keterangan (contoh: ada keperluan keluarga, demam, dll)" required></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer border-0">
                                                                <button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Batal</button>
                                                                <button type="submit" name="add_absen" class="btn btn-submit text-white rounded-pill">Simpan</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5 text-muted">
                                    <i class="bi bi-emoji-smile" style="font-size: 48px;"></i>
                                    <p class="mt-2">Semua siswa sudah absen hari ini!</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Info -->
            <div class="alert alert-info mt-3 rounded-4">
                <i class="bi bi-info-circle-fill me-2"></i>
                <strong>Informasi:</strong> 
                <ul class="mb-0 mt-2">
                    <li>Untuk status <strong>Hadir</strong>, silakan gunakan scan QR Code.</li>
                    <li>Status <strong>Izin, Sakit, Alfa</strong> dapat diinput manual di halaman ini.</li>
                    <li>Siswa yang mengajukan izin/sakit dengan bukti akan muncul ikon <i class="bi bi-paperclip"></i> dan perlu <strong>diverifikasi</strong> oleh guru.</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>