<?php
function generateSertifikat($conn, $siswa_id, $nama_siswa, $stella) {
    // Buat folder sertifikat jika belum ada
    $output_dir = 'assets/sertifikat/';
    if (!file_exists($output_dir)) {
        mkdir($output_dir, 0777, true);
    }
    
    $output_file = $output_dir . 'sertifikat_' . $siswa_id . '_' . date('Ymd') . '.png';
    
    // Ukuran sertifikat
    $width = 1200;
    $height = 850;
    
    // Buat gambar
    $img = imagecreatetruecolor($width, $height);
    
    // ==================== WARNA ====================
    $bg_dark = imagecolorallocate($img, 20, 18, 40);          // Background luar gelap
    $paper_main = imagecolorallocate($img, 255, 252, 240);    // Kertas krem
    $paper_light = imagecolorallocate($img, 255, 254, 248);   // Kertas lebih terang
    $gold_light = imagecolorallocate($img, 255, 215, 0);      // Emas terang
    $gold_medium = imagecolorallocate($img, 212, 175, 55);    // Emas medium
    $gold_dark = imagecolorallocate($img, 184, 134, 11);      // Emas gelap
    $gold_pale = imagecolorallocate($img, 238, 232, 170);     // Emas pucat
    $text_dark = imagecolorallocate($img, 45, 40, 35);        // Hitam kecoklatan
    $text_gray = imagecolorallocate($img, 120, 110, 100);     // Abu-abu elegan
    $accent = imagecolorallocate($img, 139, 69, 19);          // Coklat kemerahan
    $white = imagecolorallocate($img, 255, 255, 255);
    
    // Background luar (gelap mewah)
    imagefill($img, 0, 0, $bg_dark);
    
    // ==================== KERTAS UTAMA ====================
    $margin = 25;
    $paper_x = $margin;
    $paper_y = $margin;
    $paper_w = $width - ($margin * 2);
    $paper_h = $height - ($margin * 2);
    imagefilledrectangle($img, $paper_x, $paper_y, $paper_w, $paper_h, $paper_main);
    
    // ==================== BORDER BERTINGKAT (6 LAPIS) ====================
    // Lapis 1 - Luar tebal emas
    imagerectangle($img, $paper_x + 5, $paper_y + 5, $paper_w - 5, $paper_h - 5, $gold_medium);
    // Lapis 2 - Tipis emas terang
    imagerectangle($img, $paper_x + 10, $paper_y + 10, $paper_w - 10, $paper_h - 10, $gold_light);
    // Lapis 3 - Tebal emas gelap
    imagerectangle($img, $paper_x + 15, $paper_y + 15, $paper_w - 15, $paper_h - 15, $gold_dark);
    // Lapis 4 - Tipis emas terang
    imagerectangle($img, $paper_x + 20, $paper_y + 20, $paper_w - 20, $paper_h - 20, $gold_light);
    // Lapis 5 - Tebal emas medium
    imagerectangle($img, $paper_x + 25, $paper_y + 25, $paper_w - 25, $paper_h - 25, $gold_medium);
    // Lapis 6 - Tipis dalam
    imagerectangle($img, $paper_x + 30, $paper_y + 30, $paper_w - 30, $paper_h - 30, $gold_pale);
    
    // ==================== ORNAMEN SUDUT MEWAH ====================
    function drawElegantCorner($img, $x, $y, $gold_light, $gold_medium, $gold_dark) {
        $size = 50;
        // Garis utama
        imageline($img, $x, $y, $x + $size, $y, $gold_light);
        imageline($img, $x, $y, $x, $y + $size, $gold_light);
        // Garis kedua
        imageline($img, $x + 5, $y, $x + $size - 5, $y, $gold_medium);
        imageline($img, $x, $y + 5, $x, $y + $size - 5, $gold_medium);
        // Garis ketiga
        imageline($img, $x + 10, $y, $x + $size - 10, $y, $gold_dark);
        imageline($img, $x, $y + 10, $x, $y + $size - 10, $gold_dark);
        // Garis diagonal
        imageline($img, $x, $y, $x + 30, $y + 30, $gold_light);
        imageline($img, $x + 5, $y, $x + 30, $y + 25, $gold_medium);
        // Lingkaran dekorasi
        imagefilledellipse($img, $x + 15, $y + 15, 12, 12, $gold_light);
        imagefilledellipse($img, $x + 15, $y + 15, 6, 6, $gold_dark);
        // Ornamen tambahan
        for ($i = 1; $i <= 3; $i++) {
            imagefilledellipse($img, $x + 5 + ($i * 10), $y + 5, 3, 3, $gold_medium);
            imagefilledellipse($img, $x + 5, $y + 5 + ($i * 10), 3, 3, $gold_medium);
        }
    }
    
    // Panggil ornamen di 4 sudut
    drawElegantCorner($img, $paper_x + 8, $paper_y + 8, $gold_light, $gold_medium, $gold_dark);
    drawElegantCorner($img, $paper_w - 58, $paper_y + 8, $gold_light, $gold_medium, $gold_dark);
    drawElegantCorner($img, $paper_x + 8, $paper_h - 58, $gold_light, $gold_medium, $gold_dark);
    drawElegantCorner($img, $paper_w - 58, $paper_h - 58, $gold_light, $gold_medium, $gold_dark);
    
    // ==================== GARIS DEKORATIF ATAS & BAWAH ====================
    for ($i = $paper_x + 100; $i <= $paper_w - 100; $i += 35) {
        // Atas - motif titik-titik emas
        imageline($img, $i, $paper_y + 60, $i + 15, $paper_y + 60, $gold_light);
        imageline($img, $i + 5, $paper_y + 63, $i + 20, $paper_y + 63, $gold_medium);
        imagefilledellipse($img, $i + 8, $paper_y + 60, 4, 4, $gold_dark);
        
        // Bawah - motif titik-titik emas
        imageline($img, $i, $paper_h - 60, $i + 15, $paper_h - 60, $gold_light);
        imageline($img, $i + 5, $paper_h - 63, $i + 20, $paper_h - 63, $gold_medium);
        imagefilledellipse($img, $i + 8, $paper_h - 60, 4, 4, $gold_dark);
    }
    
    // ==================== GARIS VERTIKAL DEKORATIF ====================
    for ($i = $paper_y + 80; $i <= $paper_h - 80; $i += 40) {
        imageline($img, $paper_x + 80, $i, $paper_x + 80, $i + 15, $gold_pale);
        imageline($img, $paper_w - 80, $i, $paper_w - 80, $i + 15, $gold_pale);
    }
    
    $center_x = $width / 2;
    
    // ==================== LOGO/EMBLEM (BINTANG & LAUREL) ====================
    $emblem_y = $paper_y + 105;
    
    // Lingkaran emblem bertingkat
    for ($i = 5; $i >= 1; $i--) {
        $radius = 45 - ($i * 3);
        $color = ($i % 2 == 0) ? $gold_light : $gold_medium;
        imageellipse($img, $center_x, $emblem_y, $radius * 2, $radius * 2, $color);
    }
    
    // Daun laurel kiri (motif daun)
    for ($i = 0; $i < 10; $i++) {
        $angle = 180 + ($i * 12);
        $x = $center_x - 48 + ($i * 6);
        $y = $emblem_y - 18 + ($i * 5);
        imageellipse($img, $x, $y, 14, 8, $gold_medium);
        imageellipse($img, $x, $y, 10, 5, $gold_light);
        // Tangkai daun
        imageline($img, $x - 5, $y, $x + 5, $y, $gold_dark);
    }
    
    // Daun laurel kanan
    for ($i = 0; $i < 10; $i++) {
        $x = $center_x + 48 - ($i * 6);
        $y = $emblem_y - 18 + ($i * 5);
        imageellipse($img, $x, $y, 14, 8, $gold_medium);
        imageellipse($img, $x, $y, 10, 5, $gold_light);
        imageline($img, $x - 5, $y, $x + 5, $y, $gold_dark);
    }
    
    // Bintang utama di tengah
    $star_points = [];
    for ($i = 0; $i < 5; $i++) {
        $angle = $i * 72 * M_PI / 180;
        $x1 = $center_x + 32 * cos($angle);
        $y1 = $emblem_y + 32 * sin($angle);
        $star_points[] = $x1;
        $star_points[] = $y1;
        
        $angle2 = ($i * 72 + 36) * M_PI / 180;
        $x2 = $center_x + 14 * cos($angle2);
        $y2 = $emblem_y + 14 * sin($angle2);
        $star_points[] = $x2;
        $star_points[] = $y2;
    }
    imagefilledpolygon($img, $star_points, 10, $gold_light);
    
    // Bintang kecil di dalam
    $star_points2 = [];
    for ($i = 0; $i < 5; $i++) {
        $angle = $i * 72 * M_PI / 180;
        $x1 = $center_x + 16 * cos($angle);
        $y1 = $emblem_y + 16 * sin($angle);
        $star_points2[] = $x1;
        $star_points2[] = $y1;
        
        $angle2 = ($i * 72 + 36) * M_PI / 180;
        $x2 = $center_x + 7 * cos($angle2);
        $y2 = $emblem_y + 7 * sin($angle2);
        $star_points2[] = $x2;
        $star_points2[] = $y2;
    }
    imagefilledpolygon($img, $star_points2, 10, $gold_dark);
    
    // Lingkaran tengah
    imagefilledellipse($img, $center_x, $emblem_y, 10, 10, $gold_medium);
    
    // ==================== PATH FONT ====================
    $font_path = 'assets/fonts/PlayfairDisplay-Regular.ttf';
    if (!file_exists($font_path)) {
        $font_path = 'assets/fonts/FREESCPT.TTF';
    }
    $use_font = file_exists($font_path);
    
    // ==================== JUDUL UTAMA ====================
    $title = "IMPERIAL SCHOLAR";
    $title_y = $paper_y + 215;
    
    if ($use_font) {
        $font_size = 58;
        $bbox = imagettfbbox($font_size, 0, $font_path, $title);
        $title_width = $bbox[2] - $bbox[0];
        $title_x = $center_x - ($title_width / 2);
        imagettftext($img, $font_size, 0, $title_x, $title_y, $gold_medium, $font_path, $title);
    } else {
        $title_x = $center_x - (strlen($title) * 4.5);
        imagestring($img, 5, $title_x, $title_y, $title, $gold_medium);
    }
    
    // Garis dekoratif bawah judul
    $line_width = 320;
    imageline($img, $center_x - $line_width, $title_y + 25, $center_x + $line_width, $title_y + 25, $gold_light);
    imageline($img, $center_x - $line_width + 10, $title_y + 29, $center_x + $line_width - 10, $title_y + 29, $gold_dark);
    imageline($img, $center_x - $line_width + 20, $title_y + 33, $center_x + $line_width - 20, $title_y + 33, $gold_pale);
    
    // Bintang kecil di sisi garis
    imagefilledellipse($img, $center_x - $line_width - 10, $title_y + 27, 6, 6, $gold_light);
    imagefilledellipse($img, $center_x + $line_width + 10, $title_y + 27, 6, 6, $gold_light);
    
    // ==================== SUBTITLE ====================
    $subtitle = "CERTIFICATE OF ACHIEVEMENT";
    $subtitle_y = $title_y + 60;
    
    if ($use_font) {
        $font_size = 22;
        $bbox = imagettfbbox($font_size, 0, $font_path, $subtitle);
        $subtitle_width = $bbox[2] - $bbox[0];
        $subtitle_x = $center_x - ($subtitle_width / 2);
        imagettftext($img, $font_size, 0, $subtitle_x, $subtitle_y, $gold_dark, $font_path, $subtitle);
    } else {
        $subtitle_x = $center_x - (strlen($subtitle) * 3.5);
        imagestring($img, 4, $subtitle_x, $subtitle_y, $subtitle, $gold_dark);
    }
    
    // ==================== TEKS PENGHARGAAN ====================
    $text_y = $paper_y + 340;
    
    $line1 = "Dengan ini menyatakan bahwa:";
    $line2 = $nama_siswa;
    $line3 = "Telah berhasil mencapai gelar tertinggi";
    $line4 = "IMPERIAL SCHOLAR";
    $line5 = "dengan mengumpulkan " . $stella . " Stella";
    $line6 = "Sebagai bentuk penghargaan atas prestasi dan dedikasi";
    $line7 = "yang luar biasa dalam bidang akademik dan karakter.";
    
    if ($use_font) {
        $font_size = 18;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line1);
        $line1_width = $bbox[2] - $bbox[0];
        $line1_x = $center_x - ($line1_width / 2);
        imagettftext($img, $font_size, 0, $line1_x, $text_y, $text_dark, $font_path, $line1);
        
        $font_size = 52;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line2);
        $line2_width = $bbox[2] - $bbox[0];
        $line2_x = $center_x - ($line2_width / 2);
        imagettftext($img, $font_size, 0, $line2_x, $text_y + 60, $gold_dark, $font_path, $line2);
        
        $font_size = 18;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line3);
        $line3_width = $bbox[2] - $bbox[0];
        $line3_x = $center_x - ($line3_width / 2);
        imagettftext($img, $font_size, 0, $line3_x, $text_y + 130, $text_dark, $font_path, $line3);
        
        $font_size = 26;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line4);
        $line4_width = $bbox[2] - $bbox[0];
        $line4_x = $center_x - ($line4_width / 2);
        imagettftext($img, $font_size, 0, $line4_x, $text_y + 170, $gold_medium, $font_path, $line4);
        
        $font_size = 18;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line5);
        $line5_width = $bbox[2] - $bbox[0];
        $line5_x = $center_x - ($line5_width / 2);
        imagettftext($img, $font_size, 0, $line5_x, $text_y + 215, $text_dark, $font_path, $line5);
        
        $font_size = 14;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line6);
        $line6_width = $bbox[2] - $bbox[0];
        $line6_x = $center_x - ($line6_width / 2);
        imagettftext($img, $font_size, 0, $line6_x, $text_y + 265, $text_gray, $font_path, $line6);
        
        $font_size = 14;
        $bbox = imagettfbbox($font_size, 0, $font_path, $line7);
        $line7_width = $bbox[2] - $bbox[0];
        $line7_x = $center_x - ($line7_width / 2);
        imagettftext($img, $font_size, 0, $line7_x, $text_y + 290, $text_gray, $font_path, $line7);
    } else {
        // Fallback
        $line1_x = $center_x - (strlen($line1) * 3.5);
        $line2_x = $center_x - (strlen($line2) * 5);
        $line3_x = $center_x - (strlen($line3) * 3.5);
        $line4_x = $center_x - (strlen($line4) * 4.5);
        $line5_x = $center_x - (strlen($line5) * 3.5);
        $line6_x = $center_x - (strlen($line6) * 3.2);
        $line7_x = $center_x - (strlen($line7) * 3.2);
        
        imagestring($img, 4, $line1_x, $text_y, $line1, $text_dark);
        imagestring($img, 5, $line2_x, $text_y + 45, $line2, $gold_dark);
        imagestring($img, 4, $line3_x, $text_y + 105, $line3, $text_dark);
        imagestring($img, 5, $line4_x, $text_y + 145, $line4, $gold_medium);
        imagestring($img, 4, $line5_x, $text_y + 185, $line5, $text_dark);
        imagestring($img, 3, $line6_x, $text_y + 235, $line6, $text_gray);
        imagestring($img, 3, $line7_x, $text_y + 260, $line7, $text_gray);
    }
    
    // ==================== BINTANG DEKORASI ====================
    $deco_stars = [
        [$center_x - 250, $text_y + 80, 8],
        [$center_x + 250, $text_y + 80, 8],
        [$center_x - 220, $text_y + 190, 6],
        [$center_x + 220, $text_y + 190, 6],
        [$center_x - 200, $text_y + 240, 5],
        [$center_x + 200, $text_y + 240, 5],
        [$center_x - 180, $text_y + 310, 4],
        [$center_x + 180, $text_y + 310, 4],
    ];
    
    foreach ($deco_stars as $star) {
        imagefilledellipse($img, $star[0], $star[1], $star[2], $star[2], $gold_light);
        imagefilledellipse($img, $star[0], $star[1], $star[2]-2, $star[2]-2, $gold_dark);
    }
    
    // ==================== TANGGAL ====================
    $tanggal_text = "Diberikan tanggal: " . date('d') . " " . getBulan(date('m')) . " " . date('Y');
    $tanggal_y = $paper_h - 110;
    
    if ($use_font) {
        $font_size = 14;
        $bbox = imagettfbbox($font_size, 0, $font_path, $tanggal_text);
        $tanggal_width = $bbox[2] - $bbox[0];
        $tanggal_x = $center_x - ($tanggal_width / 2);
        imagettftext($img, $font_size, 0, $tanggal_x, $tanggal_y, $text_gray, $font_path, $tanggal_text);
    } else {
        $tanggal_x = $center_x - (strlen($tanggal_text) * 3);
        imagestring($img, 3, $tanggal_x, $tanggal_y, $tanggal_text, $text_gray);
    }
    
    // ==================== TANDA TANGAN ====================
    $sign_y = $paper_h - 75;
    
    // Tanda tangan kiri (Kepala Sekolah)
    imageline($img, $paper_x + 140, $sign_y, $paper_x + 370, $sign_y, $text_dark);
    imageline($img, $paper_x + 142, $sign_y - 2, $paper_x + 368, $sign_y - 2, $gold_pale);
    imagestring($img, 3, $paper_x + 210, $sign_y + 12, "Kepala Sekolah", $text_gray);
    
    // Tanda tangan kanan (Wali Kelas)
    imageline($img, $paper_w - 370, $sign_y, $paper_w - 140, $sign_y, $text_dark);
    imageline($img, $paper_w - 368, $sign_y - 2, $paper_w - 142, $sign_y - 2, $gold_pale);
    imagestring($img, 3, $paper_w - 350, $sign_y + 12, "Wali Kelas", $text_gray);
    
    // ==================== NOMOR SERTIFIKAT ====================
    $nomor = "Reg. No: IMP/" . date('Y') . "/" . str_pad($siswa_id, 4, '0', STR_PAD_LEFT);
    $nomor_x = $center_x - (strlen($nomor) * 2.5);
    imagestring($img, 2, $nomor_x, $paper_h - 35, $nomor, $text_gray);
    
    // ==================== WATERMARK (Logo transparan) ====================
    $watermark = "★ IMPERIAL ★";
    $watermark_x = $center_x - (strlen($watermark) * 3.5);
    $watermark_y = $paper_h - 135;
    imagestring($img, 2, $watermark_x, $watermark_y, $watermark, $gold_pale);
    
    // Simpan gambar
    imagepng($img, $output_file);
    imagedestroy($img);
    
    // Update database
    mysqli_query($conn, "UPDATE siswa SET sertifikat_file = '$output_file' WHERE id = $siswa_id");
    
    return $output_file;
}

function getBulan($bulan) {
    $nama_bulan = [
        '01' => 'Januari', '02' => 'Februari', '03' => 'Maret',
        '04' => 'April', '05' => 'Mei', '06' => 'Juni',
        '07' => 'Juli', '08' => 'Agustus', '09' => 'September',
        '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
    ];
    return $nama_bulan[$bulan];
}
?>