<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Jika role developer, redirect ke halaman khusus
if (isset($_SESSION['role']) && $_SESSION['role'] == 'developer') {
    header("Location: dashboard_developer.php");
    exit();
}

include 'config/database.php';

// waktunya
date_default_timezone_set('Asia/Jakarta');

// Cek sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];

$nama_siswa = '';
$data_poin = [];
$is_imperial = false;
$is_warning = false;
$is_blocked = false;

if ($role == 'siswa') {
    $user_id = $_SESSION['user_id'];
    $query = "SELECT nama FROM siswa WHERE user_id = $user_id";
    $res = mysqli_query($conn, $query);
    if ($row = mysqli_fetch_assoc($res)) {
        $nama_siswa = $row['nama'];
    }
    
    // Ambil data poin dan status siswa
    $query_poin = "SELECT s.stella, s.tonitrus, s.total_poin, s.nama, s.kelas, s.gelar, s.status_blokir, s.alasan_blokir FROM siswa s WHERE s.user_id = $user_id";
    $result_poin = mysqli_query($conn, $query_poin);
    $data_poin = mysqli_fetch_assoc($result_poin);
    
    // data dimulai dari nol 
    if (!$data_poin) {
        $data_poin = [
            'stella' => 0,
            'tonitrus' => 0,
            'total_poin' => 0,
            'nama' => $nama_siswa,
            'kelas' => '-',
            'gelar' => '',
            'status_blokir' => 'aktif',
            'alasan_blokir' => ''
        ];
    } else {
        $data_poin['stella'] = $data_poin['stella'] ?? 0;
        $data_poin['tonitrus'] = $data_poin['tonitrus'] ?? 0;
        $data_poin['total_poin'] = $data_poin['total_poin'] ?? 0;
        $data_poin['gelar'] = $data_poin['gelar'] ?? '';
        $data_poin['status_blokir'] = $data_poin['status_blokir'] ?? 'aktif';
    }
    
    $is_imperial = ($data_poin['gelar'] == 'Imperial Scholar');
    $is_warning = ($data_poin['status_blokir'] == 'peringatan');
    $is_blocked = ($data_poin['status_blokir'] == 'diblokir');
    // AUTO SET IMPERIAL SCHOLAR JIKA STELLA >= 8
if ($data_poin['stella'] >= 8 && $data_poin['gelar'] != 'Imperial Scholar') {
    $update = mysqli_query($conn, "UPDATE siswa SET gelar='Imperial Scholar' WHERE user_id = $user_id");
    
    $data_poin['gelar'] = 'Imperial Scholar';
    $is_imperial = true;

    // Trigger popup sekali saja
    $_SESSION['just_got_imperial'] = true;
}
}

// Ambil statistik absensi hari ini untuk guru nanti yaaa
$today = date('Y-m-d');
$stat_hadir = 0;
$stat_total = 0;
$total_siswa = 0;
$belum_absen = 0;
$sudah_pulang = 0;
$belum_pulang = 0;
$total_telat = 0;
$total_poin = 0;
$siswa_belum_absen = [];

$query_hadir = mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today' AND status='hadir'");
if ($query_hadir) {
    $stat_hadir = mysqli_fetch_assoc($query_hadir)['total'];
}

$query_total = mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today'");
if ($query_total) {
    $stat_total = mysqli_fetch_assoc($query_total)['total'];
}

$query_siswa = mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa");
if ($query_siswa) {
    $total_siswa = mysqli_fetch_assoc($query_siswa)['total'];
}

$query_pulang = mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today' AND status_pulang='sudah'");
if ($query_pulang) {
    $sudah_pulang = mysqli_fetch_assoc($query_pulang)['total'];
}

$query_telat = mysqli_query($conn, "SELECT SUM(telat) as total_telat, SUM(poin) as total_poin FROM absensi WHERE tanggal='$today'");
if ($query_telat) {
    $data_telat = mysqli_fetch_assoc($query_telat);
    $total_telat = $data_telat['total_telat'] ?? 0;
    $total_poin = $data_telat['total_poin'] ?? 0;
}

$belum_absen = $total_siswa - $stat_total;
$belum_pulang = $stat_hadir - $sudah_pulang;

if ($belum_absen > 0) {
    $query_belum = "SELECT s.id, s.nama, s.kelas 
                    FROM siswa s 
                    WHERE s.id NOT IN (
                        SELECT siswa_id FROM absensi WHERE tanggal = '$today'
                    )";
    $result_belum = mysqli_query($conn, $query_belum);
    while ($row = mysqli_fetch_assoc($result_belum)) {
        $siswa_belum_absen[] = $row;
    }
}

$total_telat_ringan = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today' AND telat BETWEEN 1 AND 15"))['total'] ?? 0;
$total_telat_sedang = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today' AND telat BETWEEN 16 AND 30"))['total'] ?? 0;
$total_telat_berat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi WHERE tanggal='$today' AND telat > 30"))['total'] ?? 0;

$batas_tonitrus_7 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_7'"))['value_setting'] ?? 7;
$batas_tonitrus_8 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_8'"))['value_setting'] ?? 8;

// Cek apakah baru saja mencapai Imperial Scholar di papan murid nanti
$show_certificate_modal = false;
if ($is_imperial && isset($_SESSION['just_got_imperial']) && $_SESSION['just_got_imperial'] == true) {
    $show_certificate_modal = true;
    $_SESSION['just_got_imperial'] = false;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <nav class="navbar-modern">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center py-2 flex-wrap">
                <span class="navbar-brand text-white"><i class="bi bi-book"></i> SekolahBISA!</span>
                <div class="d-flex align-items-center gap-3 mt-2 mt-sm-0">
                    <div class="user-info text-white">
                        <i class="bi bi-person-circle me-1"></i>
                        <?php if ($role == 'guru'): ?>
                            Guru <?= htmlspecialchars($username) ?>
                        <?php else: ?>
                            <?= htmlspecialchars($nama_siswa) ?>
                        <?php endif; ?>
                    </div>
                    <a href="logout.php" class="btn-logout text-white"><i class="bi bi-box-arrow-right"></i> Keluar</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container mt-4 mt-md-5">
        <div class="welcome-section animate-fade-in">
            <div class="welcome-badge"><i class="bi bi-calendar-check me-1"></i> Dashboard</div>
            <h2 class="mb-2 fw-bold" style="font-size: 28px;">Selamat datang, <?= ($role == 'guru') ? 'Guru ' . htmlspecialchars($username) : htmlspecialchars($nama_siswa) ?>!</h2>
            <p class="text-muted mb-0"><i class="bi bi-clock me-1"></i> <?= date('l, d F Y - H:i') ?> WIB</p>
        </div>

        <?php if ($role == 'guru'): ?>
            <!-- Statistik untuk Guru -->
            <div class="stat-grid animate-fade-in" style="animation-delay: 0.1s;">
                <div class="stat-item"><div class="stat-number text-success"><?= $stat_hadir ?></div><div class="stat-label"><i class="bi bi-check-circle-fill text-success me-1"></i> Hadir Hari Ini</div></div>
                <div class="stat-item"><div class="stat-number text-primary"><?= $stat_total ?></div><div class="stat-label"><i class="bi bi-people-fill me-1"></i> Total Absen</div></div>
                <div class="stat-item"><div class="stat-number text-warning"><?= $belum_absen ?></div><div class="stat-label"><i class="bi bi-hourglass-split me-1"></i> Belum Absen</div></div>
                <div class="stat-item"><div class="stat-number text-info"><?= $sudah_pulang ?></div><div class="stat-label"><i class="bi bi-house-door-fill me-1"></i> Sudah Pulang</div></div>
                <div class="stat-item"><div class="stat-number text-secondary"><?= $belum_pulang ?></div><div class="stat-label"><i class="bi bi-clock me-1"></i> Belum Pulang</div></div>
                <div class="stat-item"><div class="stat-number text-dark"><?= $total_siswa ?></div><div class="stat-label"><i class="bi bi-person-arms-up me-1"></i> Total Siswa</div></div>
                <div class="stat-item"><div class="stat-number text-danger"><?= $total_telat ?></div><div class="stat-label"><i class="bi bi-clock-history me-1"></i> Total Telat (menit)</div></div>
                <div class="stat-item"><div class="stat-number text-warning"><?= $total_poin ?></div><div class="stat-label"><i class="bi bi-exclamation-triangle me-1"></i> Total Poin</div></div>
                <div class="stat-item"><div class="stat-number text-warning"><?= $total_telat_ringan ?></div><div class="stat-label">Telat Ringan (1-15')</div></div>
                <div class="stat-item"><div class="stat-number text-warning"><?= $total_telat_sedang ?></div><div class="stat-label">Telat Sedang (16-30')</div></div>
                <div class="stat-item"><div class="stat-number text-danger"><?= $total_telat_berat ?></div><div class="stat-label">Telat Berat (>30')</div></div>
            </div>

            <!-- Daftar Siswa Belum Absen -->
            <?php if ($belum_absen > 0 && count($siswa_belum_absen) > 0): ?>
            <div class="card border-0 shadow-sm rounded-4 mt-4 animate-fade-in" style="animation-delay: 0.15s;">
                <div class="card-header bg-white border-0 py-3"><h5 class="mb-0 fw-semibold"><i class="bi bi-clock-history text-warning me-2"></i> Siswa Belum Absen Hari Ini <span class="badge bg-warning text-dark ms-2"><?= $belum_absen ?></span></h5></div>
                <div class="card-body pt-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light"><tr><th width="50">No</th><th><i class="bi bi-person me-1"></i> Nama Siswa</th><th><i class="bi bi-building me-1"></i> Kelas</th><th width="120"><i class="bi bi-qr-code me-1"></i> Aksi</th></tr></thead>
                            <tbody>
                                <?php $no = 1; foreach ($siswa_belum_absen as $siswa): ?>
                                <tr><td class="text-center fw-medium"><?= $no++ ?></td><td class="fw-medium"><?= htmlspecialchars($siswa['nama']) ?></td><td class="text-center"><?= htmlspecialchars($siswa['kelas']) ?></td><td class="text-center"><a href="scanner.php" class="btn-scan text-white text-decoration-none"><i class="bi bi-upc-scan"></i> Scan</a></td></tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php elseif ($belum_absen == 0 && $total_siswa > 0): ?>
            <div class="alert alert-success mt-4 animate-fade-in"><i class="bi bi-check-circle-fill me-2"></i> Semua siswa sudah melakukan absen masuk hari ini! 👍</div>
            <?php endif; ?>
            
            <!-- Menu Grid untuk Guru -->
            <div class="row g-4 animate-fade-in" style="animation-delay: 0.2s;">
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: linear-gradient(135deg, #667eea20, #764ba220); color: #667eea;"><i class="bi bi-upc-scan"></i></div><h5 class="menu-title">Scan QR Code</h5><p class="menu-desc">Scan QR siswa (Masuk/Pulang)</p><a href="scanner.php" class="btn btn-primary btn-menu"><i class="bi bi-camera"></i> Mulai Scan</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #22c55e20; color: #22c55e;"><i class="bi bi-qr-code"></i></div><h5 class="menu-title">Generate QR</h5><p class="menu-desc">Buat QR Code untuk siswa</p><a href="generate_qr.php" class="btn btn-success btn-menu"><i class="bi bi-plus-circle"></i> Generate</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #0ea5e920; color: #0ea5e9;"><i class="bi bi-file-text"></i></div><h5 class="menu-title">Laporan</h5><p class="menu-desc">Lihat rekap kehadiran</p><a href="laporan.php" class="btn btn-info btn-menu text-white"><i class="bi bi-eye"></i> Lihat</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #f59e0b20; color: #f59e0b;"><i class="bi bi-pencil-square"></i></div><h5 class="menu-title">Input Status</h5><p class="menu-desc">Kelola Izin, Sakit, Alfa</p><a href="input_status.php" class="btn btn-warning btn-menu text-white"><i class="bi bi-pencil"></i> Kelola</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #ef444420; color: #ef4444;"><i class="bi bi-clock-history"></i></div><h5 class="menu-title">Rekap Telat</h5><p class="menu-desc">Lihat siswa yang sering terlambat</p><a href="rekap_telat.php" class="btn btn-danger btn-menu"><i class="bi bi-bar-chart"></i> Lihat Rekap</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #6b728020; color: #6b7280;"><i class="bi bi-gear-fill"></i></div><h5 class="menu-title">Pengaturan</h5><p class="menu-desc">Atur jam masuk & batas telat</p><a href="pengaturan.php" class="btn btn-secondary btn-menu"><i class="bi bi-sliders2"></i> Pengaturan</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #fbbf2420; color: #f59e0b;"><i class="bi bi-trophy-fill"></i></div><h5 class="menu-title">Manajemen Poin</h5><p class="menu-desc">Kelola Stella ⭐ & Tonitrus ⚡</p><a href="poin_siswa.php" class="btn btn-warning btn-menu text-white"><i class="bi bi-star"></i> Kelola Poin</a></div></div>
                <div class="col-md-3"><div class="menu-card text-center"><div class="menu-icon" style="background: #25D36620; color: #25D366;"><i class="bi bi-shield-lock-fill"></i></div><h5 class="menu-title">Dev Panel</h5><p class="menu-desc">Pengaturan WhatsApp (Developer)</p><a href="ortu_siswa.php" class="btn btn-dark btn-menu"><i class="bi bi-gear"></i> Developer</a></div></div>
            </div>
            
        <?php elseif ($role == 'siswa'): ?>
            
            <?php if ($is_blocked): ?>
                <!-- HALAMAN BLOKIR nanti saat diminta -->
                <div class="row"><div class="col-lg-8 mx-auto"><div class="card border-0 shadow-sm rounded-4" style="background: linear-gradient(135deg, #1a1a2e, #16213e);"><div class="card-body text-center p-5"><i class="bi bi-shield-lock-fill" style="font-size: 80px; color: #ef4444;"></i><h2 class="text-danger fw-bold mt-3">AKUN DIBLOKIR</h2><p class="text-white mt-3"><?= htmlspecialchars($data_poin['alasan_blokir'] ?? 'Tonitrus mencapai batas maksimal') ?></p><div class="alert alert-danger mt-3"><i class="bi bi-exclamation-triangle-fill me-2"></i>Anda tidak dapat mengakses sistem absensi. Silakan hubungi guru BK.</div><a href="logout.php" class="btn btn-danger mt-3"><i class="bi bi-box-arrow-right"></i> Logout</a></div></div></div></div>
            <?php else: ?>
                
                <!-- Container Utama -->
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <div class="p-4 mb-4 rounded-4 <?= $is_imperial ? 'imperial-card imperial-bg' : ($is_warning ? 'warning-card' : '') ?>">
                            
                            <!-- Header dengan Gelar -->
                            <div class="text-center mb-4">
                                <?php if ($is_imperial): ?>
                                    <div class="crown-icon">👑</div>
                                    <h1 class="imperial-title mb-2">IMPERIAL SCHOLAR</h1>
                                    <div class="imperial-badge">
                                        <i class="bi bi-star-fill"></i> Elite Student 
                                        <i class="bi bi-trophy-fill"></i>
                                    </div>
                                    <p class="text-warning mt-2 small">
                                        <i class="bi bi-gem"></i> Gelar Kehormatan - Pencapaian Luar Biasa 
                                        <i class="bi bi-gem"></i>
                                    </p>
                                <?php elseif ($is_warning): ?>
                                    <div class="text-center mb-2">
                                        <span class="badge bg-danger px-4 py-2">
                                            <i class="bi bi-exclamation-triangle-fill"></i> PERINGATAN TERAKHIR! Tonitrus: <?= $data_poin['tonitrus'] ?>/<?= $batas_tonitrus_8 ?>
                                        </span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Card Poin -->
                            <div class="row g-4 mb-4">
                                <div class="col-md-4">
                                    <div class="<?= $is_imperial ? 'imperial-stats' : '' ?> p-3 rounded-3 text-center" style="background: <?= $is_imperial ? 'rgba(255,215,0,0.15)' : 'linear-gradient(135deg, #fef3c7, #fde68a)' ?>">
                                        <i class="bi bi-star-fill text-warning fs-1"></i>
                                        <h2 class="mb-0 fw-bold <?= $is_imperial ? 'golden-text' : 'text-warning' ?>" style="font-size: 42px;"><?= $data_poin['stella'] ?></h2>
                                        <small>⭐ Stella Penghargaan</small>
                                        <?php if ($is_imperial): ?>
                                            <div class="mt-1"><span class="badge bg-warning text-dark">👑 Target Tercapai!</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="<?= $is_imperial ? 'imperial-stats' : '' ?> p-3 rounded-3 text-center" style="background: <?= $is_imperial ? 'rgba(255,215,0,0.15)' : 'linear-gradient(135deg, #fee2e2, #fecaca)' ?>">
                                        <i class="bi bi-lightning-charge-fill text-danger fs-1"></i>
                                        <h2 class="mb-0 fw-bold <?= $is_warning ? 'warning-text' : 'text-danger' ?>" style="font-size: 42px;"><?= $data_poin['tonitrus'] ?></h2>
                                        <small>⚡ Tonitrus Pelanggaran</small>
                                        <?php if ($is_warning): ?>
                                            <div class="mt-1"><span class="badge bg-danger">⚠️ Hati-hati!</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="<?= $is_imperial ? 'imperial-stats' : '' ?> p-3 rounded-3 text-center" style="background: <?= $is_imperial ? 'rgba(255,215,0,0.15)' : 'linear-gradient(135deg, #e0e7ff, #c7d2fe)' ?>">
                                        <i class="bi bi-calculator-fill text-primary fs-1"></i>
                                        <h2 class="mb-0 fw-bold text-primary" style="font-size: 42px;"><?= $data_poin['total_poin'] ?></h2>
                                        <small>📊 Total Poin</small>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Progress Bars -->
                            <div class="row g-3 mb-4">
                                <div class="col-md-6">
                                    <div class="p-3 rounded-3" style="background: <?= $is_imperial ? 'rgba(255,215,0,0.1)' : '#f8fafc' ?>">
                                        <div class="d-flex justify-content-between mb-1">
                                            <small><i class="bi bi-lightning-charge-fill text-danger"></i> <strong>Tonitrus</strong></small>
                                            <small><?= min(100, round(($data_poin['tonitrus'] / $batas_tonitrus_8) * 100)) ?>%</small>
                                        </div>
                                        <div class="progress" style="height: 12px; border-radius: 10px;">
                                            <div class="progress-bar <?= $data_poin['tonitrus'] >= $batas_tonitrus_7 ? 'bg-danger' : 'bg-warning' ?>" 
                                                 style="width: <?= min(100, round(($data_poin['tonitrus'] / $batas_tonitrus_8) * 100)) ?>%">
                                            </div>
                                        </div>
                                        <small class="text-muted">Peringatan: <?= $batas_tonitrus_7 ?> | Blokir: <?= $batas_tonitrus_8 ?></small>
                                        <?php if ($is_warning): ?>
                                            <div class="text-danger mt-1"><i class="bi bi-exclamation-triangle-fill"></i> PERINGATAN! Jika mencapai <?= $batas_tonitrus_8 ?>, akun akan DIBLOKIR!</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="p-3 rounded-3" style="background: <?= $is_imperial ? 'rgba(255,215,0,0.1)' : '#f8fafc' ?>">
                                        <div class="d-flex justify-content-between mb-1">
                                            <small><i class="bi bi-crown-fill text-warning"></i> <strong>Menuju Imperial Scholar</strong></small>
                                            <small><?= min(100, round(($data_poin['stella'] / 8) * 100)) ?>%</small>
                                        </div>
                                        <div class="progress" style="height: 12px; border-radius: 10px;">
                                            <div class="progress-bar bg-warning" style="width: <?= min(100, round(($data_poin['stella'] / 8) * 100)) ?>%"></div>
                                        </div>
                                        <small class="text-muted">Butuh <?= max(0, 8 - $data_poin['stella']) ?> Stella lagi</small>
                                        <?php if ($is_imperial): ?>
                                            <div class="text-warning mt-1"><i class="bi bi-trophy-fill"></i> Selamat! Anda telah mencapai gelar Imperial Scholar!</div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- QR CODE -->
                            <div class="text-center">
                                <?php if ($is_imperial): ?>
                                    <div class="imperial-qr">
                                        <div class="position-relative d-inline-block">
                                            <div class="qr-code-imperial">
                                                <?php
                                                $qr = mysqli_query($conn, "SELECT qr_code FROM siswa WHERE user_id = $user_id");
                                                if ($qr_data = mysqli_fetch_assoc($qr)) {
                                                    if (!empty($qr_data['qr_code']) && file_exists($qr_data['qr_code'])) {
                                                        echo "<img src='" . $qr_data['qr_code'] . "' alt='QR Code' style='width: 200px; height: auto; border-radius: 20px;'>";
                                                    } else {
                                                        echo '<div class="text-center py-4"><i class="bi bi-qr-code-scan" style="font-size: 100px; color: #cbd5e1;"></i><p class="text-danger mt-3">QR Code belum digenerate oleh guru.</p></div>';
                                                    }
                                                }
                                                ?>
                                            </div>
                                            <div class="sparkle" style="position: absolute; top: -10px; right: -10px;">✨</div>
                                            <div class="sparkle" style="position: absolute; bottom: -10px; left: -10px; animation-delay: 0.5s;">✨</div>
                                        </div>
                                        <h3 class="mt-3 imperial-title" style="font-size: 22px;">
                                            <i class="bi bi-qr-code-scan"></i> QR Code Imperial
                                        </h3>
                                        <p class="text-warning-emphasis">
                                            <i class="bi bi-info-circle"></i> QR Code Premium - Tunjukkan dengan bangga!
                                        </p>
                                    </div>
                                <?php else: ?>
                                    <div class="qr-card">
                                        <div class="qr-image">
                                            <?php
                                            $qr = mysqli_query($conn, "SELECT qr_code FROM siswa WHERE user_id = $user_id");
                                            if ($qr_data = mysqli_fetch_assoc($qr)) {
                                                if (!empty($qr_data['qr_code']) && file_exists($qr_data['qr_code'])) {
                                                    echo "<img src='" . $qr_data['qr_code'] . "' alt='QR Code'>";
                                                    echo "<p class='mt-2 small text-muted'>QR Code milik: <strong>" . htmlspecialchars($nama_siswa) . "</strong></p>";
                                                } else {
                                                    echo '<div class="text-center py-4"><i class="bi bi-qr-code-scan" style="font-size: 80px; color: #cbd5e1;"></i><p class="text-danger mt-3">QR Code belum digenerate oleh guru.</p></div>';
                                                }
                                            }
                                            ?>
                                        </div>
                                        <h4 class="qr-title">QR Code Absensi</h4>
                                        <p class="qr-subtitle"><i class="bi bi-info-circle me-1"></i> Tunjukkan QR Code ini kepada guru untuk absen MASUK atau PULANG</p>
                                        <div class="alert alert-info mt-3" style="border-radius: 16px;"><i class="bi bi-clock-history me-2"></i> • Scan pagi → Absen Masuk<br> • Scan sore → Absen Pulang</div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <!-- Tombol untuk Siswa -->
                            <div class="row mt-4 g-3">
                                <div class="col-md-6">
                                    <a href="ajukan_izin.php" class="btn <?= $is_imperial ? 'btn-warning' : 'btn-ajukan' ?> text-white w-100 py-3 rounded-4 text-decoration-none" style="<?= $is_imperial ? 'background: linear-gradient(135deg, #ffd700, #ffaa00); font-weight: bold;' : '' ?>">
                                        <i class="bi bi-file-earmark-text me-2"></i> 📝 Ajukan Izin / Sakit
                                    </a>
                                </div>
                                <div class="col-md-6">
                                    <a href="riwayat_poin_siswa.php" class="btn <?= $is_imperial ? 'btn-outline-warning' : 'btn-outline-primary' ?> w-100 py-3 rounded-4 text-decoration-none">
                                        <i class="bi bi-clock-history me-2"></i> 📜 Lihat Riwayat Poin
                                    </a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Modal Sertifikat Imperial Scholar -->
    <?php if ($is_imperial): ?>
    <div class="modal fade" id="certificateModal" tabindex="-1" data-bs-backdrop="static">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content" style="background: linear-gradient(135deg, #fff8e7, #fff0d0); border-radius: 20px; border: 3px solid #ffd700;">
                <div class="modal-header border-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body text-center p-4">
                    <div style="position: relative; padding: 30px; border: 2px solid #ffd700; border-radius: 15px; margin-bottom: 20px;">
                        <div style="position: absolute; top: -15px; left: 50%; transform: translateX(-50%); background: #fff0d0; padding: 0 15px;">
                            <i class="bi bi-crown-fill" style="font-size: 30px; color: #ffd700;"></i>
                        </div>
                        <h2 style="font-size: 28px; font-weight: 800; background: linear-gradient(135deg, #ffd700, #ffaa00); -webkit-background-clip: text; background-clip: text; color: transparent; margin: 20px 0 10px;">IMPERIAL SCHOLAR</h2>
                        <p style="font-size: 14px; color: #6b7280;">CERTIFICATE OF ACHIEVEMENT</p>
                        <h3 style="font-size: 28px; font-weight: 700; color: #1a1a2e; margin: 15px 0;"><?= htmlspecialchars($nama_siswa) ?></h3>
                        <p style="font-size: 14px; color: #4b5563;">Telah mencapai gelar tertinggi <strong>IMPERIAL SCHOLAR</strong><br>dengan mengumpulkan <strong><?= $data_poin['stella'] ?> Stella</strong></p>
                        <div style="background: rgba(255,215,0,0.15); border-radius: 10px; padding: 10px; margin: 15px 0;">
                            <table style="width: 100%; text-align: center; font-size: 12px;">
                                <tr><td>📊 <?= $data_poin['stella'] ?> Stella</td><td>📅 <?= date('d-m-Y') ?></td><td>🏫 <?= htmlspecialchars($data_poin['kelas'] ?? '-') ?></td></tr>
                            </table>
                        </div>
                        <div style="margin-top: 20px;"><i class="bi bi-star-fill" style="color: #ffd700;"></i><i class="bi bi-star-fill" style="color: #ffd700;"></i><i class="bi bi-star-fill" style="color: #ffd700;"></i></div>
                    </div>
                    <h4 class="fw-bold mt-3" style="color: #1a1a2e;">🎉 SELAMAT! 🎉</h4>
                    <p class="mb-3">Anda telah resmi menjadi <strong class="text-warning">Imperial Scholar</strong>!<br>Download sertifikat Anda sebagai bukti prestasi.</p>
                    <div class="d-flex gap-3 justify-content-center">
                        <a href="sertifikat_imperial.php" class="btn btn-warning rounded-pill px-4"><i class="bi bi-download"></i> Download Sertifikat</a>
                        <button class="btn btn-outline-secondary rounded-pill px-4" data-bs-dismiss="modal"><i class="bi bi-x-circle"></i> Tutup</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if ($show_certificate_modal): ?>
            var myModal = new bootstrap.Modal(document.getElementById('certificateModal'));
            myModal.show();
            <?php endif; ?>
        });
    </script>
    <?php endif; ?>
    <!-- Tombol Sertifikat - Hanya untuk Imperial Scholar -->
<?php if ($is_imperial): ?>
<div class="row mt-2">
    <div class="col-lg-8 mx-auto">
        <a href="sertifikat_imperial.php" class="btn btn-warning w-100 py-2 rounded-4 text-decoration-none">
            <i class="bi bi-award-fill me-2"></i> 
            🎓 Lihat & Download Sertifikat Imperial Scholar
        </a>
    </div>
</div>
<?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>