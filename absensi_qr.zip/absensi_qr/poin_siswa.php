<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header("Location: index.php");
    exit();
}

// ==================== FUNGSI UPDATE GELAR ====================
function updateGelar($conn, $siswa_id) {
    $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT stella, sertifikat_diberikan FROM siswa WHERE id = $siswa_id"));
    $batas_imperial = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_imperial_scholar'"))['value_setting'] ?? 8;
    
    if ($cek['stella'] >= $batas_imperial) {
        mysqli_query($conn, "UPDATE siswa SET gelar = 'Imperial Scholar', tanggal_imperial = CURDATE() WHERE id = $siswa_id");
        
        if ($cek['sertifikat_diberikan'] == '0') {
            mysqli_query($conn, "UPDATE siswa SET sertifikat_diberikan = '1' WHERE id = $siswa_id");
            mysqli_query($conn, "INSERT INTO riwayat_poin (siswa_id, jenis, jumlah, alasan, tanggal, waktu, diberikan_oleh) 
                                 VALUES ('$siswa_id', 'stella', 0, '🏆 Mendapatkan Sertifikat Imperial Scholar!', CURDATE(), CURTIME(), 'Sistem')");
            return true;
        }
        return true;
    } else {
        mysqli_query($conn, "UPDATE siswa SET gelar = '' WHERE id = $siswa_id AND gelar = 'Imperial Scholar'");
        return false;
    }
}

// ==================== FUNGSI UPDATE STATUS BLOKIR ====================
function updateStatusBlokir($conn, $siswa_id) {
    $cek = mysqli_fetch_assoc(mysqli_query($conn, "SELECT tonitrus FROM siswa WHERE id = $siswa_id"));
    $batas_7 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_7'"))['value_setting'] ?? 7;
    $batas_8 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_8'"))['value_setting'] ?? 8;
    
    if ($cek['tonitrus'] >= $batas_8) {
        mysqli_query($conn, "UPDATE siswa SET status_blokir = 'diblokir', alasan_blokir = 'Tonitrus mencapai $batas_8 poin - Dikeluarkan dari sekolah' WHERE id = $siswa_id");
        return 'diblokir';
    } elseif ($cek['tonitrus'] >= $batas_7) {
        mysqli_query($conn, "UPDATE siswa SET status_blokir = 'peringatan', alasan_blokir = 'Tonitrus mencapai $batas_7 poin - Peringatan terakhir' WHERE id = $siswa_id");
        return 'peringatan';
    } else {
        mysqli_query($conn, "UPDATE siswa SET status_blokir = 'aktif', alasan_blokir = NULL WHERE id = $siswa_id");
        return 'aktif';
    }
}

// ==================== FUNGSI GENERATE SERTIFIKAT ====================
function generateSertifikatCanva($conn, $siswa_id, $nama_siswa, $stella) {
    $template_path = 'assets/sertifikat_template.png';
    
    // Buat folder jika belum ada
    $output_dir = 'assets/sertifikat/';
    if (!file_exists($output_dir)) {
        mkdir($output_dir, 0777, true);
    }
    
    $output_file = $output_dir . 'sertifikat_' . $siswa_id . '_' . date('Ymd') . '.png';
    
    // Jika template tidak ada, buat sertifikat sederhana
    if (!file_exists($template_path)) {
        $img = imagecreatetruecolor(800, 600);
        $white = imagecolorallocate($img, 255, 255, 255);
        $gold = imagecolorallocate($img, 255, 215, 0);
        $black = imagecolorallocate($img, 0, 0, 0);
        
        imagefill($img, 0, 0, $white);
        imagerectangle($img, 10, 10, 790, 590, $gold);
        imagestring($img, 5, 280, 200, "IMPERIAL SCHOLAR", $gold);
        imagestring($img, 5, 250, 280, $nama_siswa, $black);
        imagestring($img, 4, 300, 350, $stella . " Stella", $gold);
        imagestring($img, 3, 300, 400, date('d-m-Y'), $black);
        
        imagepng($img, $output_file);
        imagedestroy($img);
        
        mysqli_query($conn, "UPDATE siswa SET sertifikat_file = '$output_file' WHERE id = $siswa_id");
        return $output_file;
    }
    
    // Jika template ada
    $img = imagecreatefrompng($template_path);
    if (!$img) return false;
    
    $black = imagecolorallocate($img, 0, 0, 0);
    $gold = imagecolorallocate($img, 255, 215, 0);
    
    // Posisi (sesuaikan dengan template Anda)
    $nama_x = 400;
    $nama_y = 300;
    
    imagestring($img, 5, $nama_x, $nama_y, $nama_siswa, $black);
    
    imagepng($img, $output_file);
    imagedestroy($img);
    
    mysqli_query($conn, "UPDATE siswa SET sertifikat_file = '$output_file' WHERE id = $siswa_id");
    return $output_file;
}

// Ambil daftar siswa
$query_siswa = "SELECT s.id, s.nama, s.kelas, s.stella, s.tonitrus, s.total_poin, s.status_blokir, s.alasan_blokir, s.gelar
                FROM siswa s 
                ORDER BY s.nama ASC";
$result_siswa = mysqli_query($conn, $query_siswa);

// Proses tambah poin
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['tambah_stella'])) {
        $siswa_id = $_POST['siswa_id'];
        $jumlah = (int)$_POST['jumlah'];
        $alasan = mysqli_real_escape_string($conn, $_POST['alasan']);
        
        // Ambil data siswa sebelum update
        $query_siswa_data = mysqli_query($conn, "SELECT nama, stella FROM siswa WHERE id = $siswa_id");
        $data_siswa = mysqli_fetch_assoc($query_siswa_data);
        $nama_siswa = $data_siswa['nama'];
        $stella_lama = $data_siswa['stella'];
        
        // Update stella
        mysqli_query($conn, "UPDATE siswa SET stella = stella + $jumlah, total_poin = total_poin + $jumlah WHERE id = $siswa_id");
        mysqli_query($conn, "INSERT INTO riwayat_poin (siswa_id, jenis, jumlah, alasan, tanggal, waktu, diberikan_oleh) 
                             VALUES ('$siswa_id', 'stella', '$jumlah', '$alasan', CURDATE(), CURTIME(), '{$_SESSION['username']}')");
        
        // Cek apakah menjadi Imperial Scholar
        $stella_baru = $stella_lama + $jumlah;
        $batas_imperial = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_imperial_scholar'"))['value_setting'] ?? 8;
        $menjadi_imperial = ($stella_baru >= $batas_imperial && $stella_lama < $batas_imperial);
        
        // Update gelar
        updateGelar($conn, $siswa_id);
        
        if ($menjadi_imperial) {
            // Generate sertifikat
            generateSertifikatCanva($conn, $siswa_id, $nama_siswa, $stella_baru);
            $_SESSION['just_got_imperial'] = true;
            $message = "⭐ Stella +$jumlah berhasil ditambahkan! 🎉👑 SELAMAT! SISWA MENJADI IMPERIAL SCHOLAR! Sertifikat telah dibuat.";
        } else {
            $message = "⭐ Stella +$jumlah berhasil ditambahkan!";
        }
        
    } elseif (isset($_POST['tambah_tonitrus'])) {
        $siswa_id = $_POST['siswa_id'];
        $jumlah = (int)$_POST['jumlah'];
        $alasan = mysqli_real_escape_string($conn, $_POST['alasan']);
        
        mysqli_query($conn, "UPDATE siswa SET tonitrus = tonitrus + $jumlah, total_poin = total_poin - $jumlah WHERE id = $siswa_id");
        mysqli_query($conn, "INSERT INTO riwayat_poin (siswa_id, jenis, jumlah, alasan, tanggal, waktu, diberikan_oleh) 
                             VALUES ('$siswa_id', 'tonitrus', '$jumlah', '$alasan', CURDATE(), CURTIME(), '{$_SESSION['username']}')");
        
        $status = updateStatusBlokir($conn, $siswa_id);
        
        if ($status == 'diblokir') {
            $message = "⚡ Tonitrus +$jumlah berhasil ditambahkan! 🚫 SISWA TELAH DIBLOKIR!";
        } elseif ($status == 'peringatan') {
            $message = "⚡ Tonitrus +$jumlah berhasil ditambahkan! ⚠️ PERINGATAN TERAKHIR!";
        } else {
            $message = "⚡ Tonitrus +$jumlah berhasil ditambahkan!";
        }
        
    } elseif (isset($_POST['reset_poin'])) {
        $siswa_id = $_POST['siswa_id'];
        mysqli_query($conn, "UPDATE siswa SET stella = 0, tonitrus = 0, total_poin = 0, status_blokir = 'aktif', alasan_blokir = NULL, gelar = '', sertifikat_diberikan = '0' WHERE id = $siswa_id");
        $message = "Poin berhasil direset!";
    }
}

// Ambil pengaturan
$batas_tonitrus_7 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_7'"))['value_setting'] ?? 7;
$batas_tonitrus_8 = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_tonitrus_8'"))['value_setting'] ?? 8;
$batas_stella = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_stella'"))['value_setting'] ?? 10;
$batas_imperial = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'batas_imperial_scholar'"))['value_setting'] ?? 8;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Poin - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/poin_siswa.css">
</head>
<body>
    <div class="main-card animate-fade-in">
        <div class="card-header-gradient text-white">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h2 class="mb-1 fw-bold"><i class="bi bi-trophy-fill me-2"></i> Manajemen Poin</h2>
                    <p class="mb-0 opacity-75">Kelola Stella ⭐ dan Tonitrus ⚡ siswa</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill mt-2 mt-sm-0"><i class="bi bi-arrow-left"></i> Kembali</a>
            </div>
        </div>
        
        <div class="p-4">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show rounded-4" role="alert">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Info Batas Cards -->
            <div class="row g-3 mb-4">
                <div class="col-md-3"><div class="stat-card text-center"><div class="stat-icon mb-2"><i class="bi bi-exclamation-triangle-fill fs-1 text-warning"></i></div><h5 class="mb-1">⚠️ Peringatan</h5><p class="mb-0 text-muted">Tonitrus ≥ <?= $batas_tonitrus_7 ?></p></div></div>
                <div class="col-md-3"><div class="stat-card text-center"><div class="stat-icon mb-2"><i class="bi bi-shield-lock-fill fs-1 text-danger"></i></div><h5 class="mb-1">🚫 Blokir</h5><p class="mb-0 text-muted">Tonitrus ≥ <?= $batas_tonitrus_8 ?></p></div></div>
                <div class="col-md-3"><div class="stat-card text-center"><div class="stat-icon mb-2"><i class="bi bi-gift-fill fs-1 text-success"></i></div><h5 class="mb-1">⭐ Reward</h5><p class="mb-0 text-muted">Stella ≥ <?= $batas_stella ?></p></div></div>
                <div class="col-md-3"><div class="stat-card text-center" style="background: linear-gradient(135deg, #fef3c7, #fde68a);"><div class="stat-icon mb-2"><i class="bi bi-crown-fill fs-1 text-warning"></i></div><h5 class="mb-1">👑 Imperial Scholar</h5><p class="mb-0">Stella ≥ <?= $batas_imperial ?></p></div></div>
            </div>
            
            <!-- Tabel Data -->
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-0">
                    <div class="p-3 border-bottom bg-light rounded-top-4"><h5 class="mb-0 fw-semibold"><i class="bi bi-table me-2 text-primary"></i> Daftar Siswa</h5></div>
                    <div class="table-responsive">
                        <table class="table table-modern mb-0">
                            <thead><tr><th>No</th><th>Nama Siswa</th><th>Kelas</th><th class="text-center">⭐ Stella</th><th class="text-center">⚡ Tonitrus</th><th class="text-center">📊 Total</th><th class="text-center">Gelar</th><th class="text-center">Status</th><th class="text-center">Aksi</th></tr></thead>
                            <tbody>
                                <?php $no=1; while($siswa = mysqli_fetch_assoc($result_siswa)): ?>
                                <tr class="<?= $siswa['status_blokir'] == 'diblokir' ? 'table-danger' : ($siswa['status_blokir'] == 'peringatan' ? 'table-warning' : '') ?>">
                                    <td class="fw-medium"><?= $no++ ?></td>
                                    <td class="fw-medium"><?= htmlspecialchars($siswa['nama']) ?></td>
                                    <td><?= htmlspecialchars($siswa['kelas']) ?></td>
                                    <td class="text-center"><span class="badge-stella"><i class="bi bi-star-fill me-1"></i> <?= $siswa['stella'] ?></span></td>
                                    <td class="text-center"><span class="badge-tonitrus"><i class="bi bi-lightning-charge-fill me-1"></i> <?= $siswa['tonitrus'] ?></span></td>
                                    <td class="text-center"><span class="badge-total"><i class="bi bi-calculator-fill me-1"></i> <?= $siswa['total_poin'] ?></span></td>
                                    <td class="text-center"><?php if ($siswa['gelar'] == 'Imperial Scholar'): ?><span class="badge-gelar"><i class="bi bi-crown-fill me-1"></i> Imperial Scholar</span><?php else: ?><span class="text-muted">-</span><?php endif; ?></td>
                                    <td class="text-center"><?php if ($siswa['status_blokir'] == 'diblokir'): ?><span class="badge-diblokir"><i class="bi bi-shield-lock-fill me-1"></i> Diblokir</span><?php elseif ($siswa['status_blokir'] == 'peringatan'): ?><span class="badge-peringatan"><i class="bi bi-exclamation-triangle-fill me-1"></i> Peringatan</span><?php else: ?><span class="badge-aktif"><i class="bi bi-check-circle-fill me-1"></i> Aktif</span><?php endif; ?></td>
                                    <td class="text-center">
                                        <?php if ($siswa['status_blokir'] != 'diblokir'): ?>
                                        <button class="btn btn-stella me-1" data-bs-toggle="modal" data-bs-target="#stellaModal<?= $siswa['id'] ?>"><i class="bi bi-star"></i> Stella</button>
                                        <button class="btn btn-tonitrus me-1" data-bs-toggle="modal" data-bs-target="#tonitrusModal<?= $siswa['id'] ?>"><i class="bi bi-lightning"></i> Tonitrus</button>
                                        <?php endif; ?>
                                        <button class="btn btn-reset" data-bs-toggle="modal" data-bs-target="#resetModal<?= $siswa['id'] ?>"><i class="bi bi-arrow-repeat"></i></button>
                                    </td>
                                </tr>
                                
                                <!-- Modal Stella -->
                                <div class="modal fade" id="stellaModal<?= $siswa['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered"><div class="modal-content modal-content-custom">
                                        <div class="modal-header modal-header-custom" style="background: linear-gradient(135deg, #fbbf24, #f59e0b);"><h5 class="modal-title fw-bold text-white"><i class="bi bi-star-fill me-2"></i> Tambah Stella</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
                                        <form method="post"><div class="modal-body p-4"><input type="hidden" name="siswa_id" value="<?= $siswa['id'] ?>"><div class="mb-3"><label class="form-label fw-semibold">Siswa</label><input type="text" class="form-control rounded-pill" value="<?= htmlspecialchars($siswa['nama']) ?>" disabled></div><div class="mb-3"><label class="form-label fw-semibold">Jumlah Stella</label><input type="number" name="jumlah" class="form-control rounded-pill" min="1" max="10" value="1" required></div><div class="mb-3"><label class="form-label fw-semibold">Alasan / Prestasi</label><textarea name="alasan" class="form-control rounded-3" rows="2" placeholder="Contoh: Juara kelas, Disiplin, Membantu teman" required></textarea></div></div><div class="modal-footer border-0 pb-4 pe-4"><button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Batal</button><button type="submit" name="tambah_stella" class="btn btn-warning rounded-pill px-4"><i class="bi bi-star-fill me-1"></i> Tambah Stella</button></div></form>
                                    </div></div>
                                </div>
                                
                                <!-- Modal Tonitrus -->
                                <div class="modal fade" id="tonitrusModal<?= $siswa['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered"><div class="modal-content modal-content-custom">
                                        <div class="modal-header modal-header-custom" style="background: linear-gradient(135deg, #ef4444, #dc2626);"><h5 class="modal-title fw-bold text-white"><i class="bi bi-lightning-charge-fill me-2"></i> Tambah Tonitrus</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
                                        <form method="post"><div class="modal-body p-4"><input type="hidden" name="siswa_id" value="<?= $siswa['id'] ?>"><div class="mb-3"><label class="form-label fw-semibold">Siswa</label><input type="text" class="form-control rounded-pill" value="<?= htmlspecialchars($siswa['nama']) ?>" disabled></div><div class="mb-3"><label class="form-label fw-semibold">Jumlah Tonitrus</label><input type="number" name="jumlah" class="form-control rounded-pill" min="1" max="10" value="1" required></div><div class="mb-3"><label class="form-label fw-semibold">Alasan Pelanggaran</label><textarea name="alasan" class="form-control rounded-3" rows="2" placeholder="Contoh: Terlambat, Tidak mengerjakan tugas" required></textarea></div></div><div class="modal-footer border-0 pb-4 pe-4"><button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Batal</button><button type="submit" name="tambah_tonitrus" class="btn btn-danger rounded-pill px-4"><i class="bi bi-lightning-charge-fill me-1"></i> Tambah Tonitrus</button></div></form>
                                    </div></div>
                                </div>
                                
                                <!-- Modal Reset -->
                                <div class="modal fade" id="resetModal<?= $siswa['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered"><div class="modal-content modal-content-custom">
                                        <div class="modal-header modal-header-custom" style="background: linear-gradient(135deg, #6b7280, #4b5563);"><h5 class="modal-title fw-bold text-white"><i class="bi bi-arrow-repeat me-2"></i> Reset Poin</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
                                        <form method="post"><div class="modal-body p-4"><input type="hidden" name="siswa_id" value="<?= $siswa['id'] ?>"><div class="text-center py-3"><i class="bi bi-exclamation-triangle-fill text-warning" style="font-size: 48px;"></i><p class="mt-3 fw-semibold">Yakin ingin mereset semua poin <br> <span class="text-primary"><?= htmlspecialchars($siswa['nama']) ?></span>?</p><p class="text-muted small">Tindakan ini tidak dapat dibatalkan.</p></div></div><div class="modal-footer border-0 justify-content-center pb-4"><button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Batal</button><button type="submit" name="reset_poin" class="btn btn-danger rounded-pill px-4"><i class="bi bi-trash me-1"></i> Reset</button></div></form>
                                    </div></div>
                                </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="text-center mt-4">
        <a href="dashboard.php" class="btn btn-secondary rounded-pill px-4 py-2"><i class="bi bi-arrow-left"></i> Kembali ke Dashboard</a>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>