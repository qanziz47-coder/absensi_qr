<?php
session_start();
include 'config/database.php';

// Simpan role asli
$original_role = $_SESSION['role'] ?? '';

// Set role sementara menjadi guru untuk preview
$_SESSION['role'] = 'guru';

// Include dashboard guru
include 'dashboard.php';

// Kembalikan role asli setelah selesai
$_SESSION['role'] = $original_role;
?>