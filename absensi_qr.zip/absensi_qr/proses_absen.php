<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    echo "Akses ditolak";
    exit();
}

// Fungsi kirim WhatsApp (support personal & grup)
function kirimWA($target, $pesan) {
    // Cek apakah notifikasi WA diaktifkan
    $wa_enabled = mysqli_fetch_assoc(mysqli_query($GLOBALS['conn'], "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_enabled'"))['value_setting'] ?? 'false';
    if ($wa_enabled != 'true') return false;
    
    $api_key = mysqli_fetch_assoc(mysqli_query($GLOBALS['conn'], "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_api_key'"))['value_setting'] ?? '';
    if (empty($api_key)) return false;
    
    // Jika target BUKAN ID grup (tidak mengandung @g.us), format nomor biasa
    if (strpos($target, '@g.us') === false) {
        $target = preg_replace('/^0/', '62', $target);
        $target = preg_replace('/[^0-9]/', '', $target);
    }
    
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://api.fonnte.com/send',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => array(
            'target' => $target,
            'message' => $pesan,
        ),
        CURLOPT_HTTPHEADER => array(
            'Authorization: ' . $api_key
        ),
    ));
    
    $response = curl_exec($curl);
    curl_close($curl);
    return $response;
}

// Ambil pengaturan
$settings = [];
$query_set = mysqli_query($conn, "SELECT key_setting, value_setting FROM pengaturan");
while ($row = mysqli_fetch_assoc($query_set)) {
    $settings[$row['key_setting']] = $row['value_setting'];
}

$jam_masuk_sekolah = $settings['jam_masuk'] ?? '07:00:00';
$batas_telat_ringan = (int)($settings['batas_telat_ringan'] ?? 15);
$batas_telat_sedang = (int)($settings['batas_telat_sedang'] ?? 30);
$poin_ringan = (int)($settings['poin_telat_ringan'] ?? 1);
$poin_sedang = (int)($settings['poin_telat_sedang'] ?? 2);
$poin_berat = (int)($settings['poin_telat_berat'] ?? 3);

// Ambil ID Grup WhatsApp untuk notifikasi
$wa_group_id = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_group_id'"))['value_setting'] ?? '';
$wa_enabled = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_enabled'"))['value_setting'] ?? 'false';
$api_key = mysqli_fetch_assoc(mysqli_query($conn, "SELECT value_setting FROM pengaturan WHERE key_setting = 'wa_api_key'"))['value_setting'] ?? '';

$qr_data = $_POST['qr_data'];
$waktu_sekarang = date('H:i:s');
$tanggal = date('Y-m-d');

function hitungTelat($waktu_absen, $jam_masuk) {
    $waktu_masuk_dt = new DateTime($jam_masuk);
    $waktu_absen_dt = new DateTime($waktu_absen);
    
    if ($waktu_absen_dt > $waktu_masuk_dt) {
        $diff = $waktu_masuk_dt->diff($waktu_absen_dt);
        $total_menit = ($diff->h * 60) + $diff->i;
        return [
            'telat' => $total_menit,
            'jam' => $diff->h,
            'menit' => $diff->i,
            'format' => ($diff->h > 0 ? $diff->h . ' jam ' : '') . $diff->i . ' menit'
        ];
    }
    return ['telat' => 0, 'jam' => 0, 'menit' => 0, 'format' => 'Tepat waktu'];
}

$telat_data = hitungTelat($waktu_sekarang, $jam_masuk_sekolah);
$telat = $telat_data['telat'];

if ($telat == 0) {
    $kategori_telat = 'Tepat Waktu';
    $poin = 0;
} elseif ($telat <= $batas_telat_ringan) {
    $kategori_telat = 'Telat Ringan';
    $poin = $poin_ringan;
} elseif ($telat <= $batas_telat_sedang) {
    $kategori_telat = 'Telat Sedang';
    $poin = $poin_sedang;
} else {
    $kategori_telat = 'Telat Berat';
    $poin = $poin_berat;
}

if (strpos($qr_data, "ABSEN|") === 0) {
    $parts = explode("|", $qr_data);
    
    if (count($parts) >= 2) {
        $siswa_id = (int)$parts[1];
        
        $cekSiswa = mysqli_query($conn, "SELECT s.id, s.nama, s.kelas, s.nomor_ortu FROM siswa s WHERE s.id = $siswa_id");
        if (mysqli_num_rows($cekSiswa) == 0) {
            echo "QR Code tidak valid (siswa tidak ditemukan).";
            exit();
        }
        
        $siswa = mysqli_fetch_assoc($cekSiswa);
        $cekAbsen = mysqli_query($conn, "SELECT id, waktu, status_pulang, telat FROM absensi WHERE siswa_id = $siswa_id AND tanggal = '$tanggal'");
        
        if (mysqli_num_rows($cekAbsen) == 0) {
            // ABSEN MASUK
            $query = "INSERT INTO absensi (siswa_id, tanggal, waktu, telat, kategori_telat, poin, status, waktu_pulang, status_pulang) 
                      VALUES ('$siswa_id', '$tanggal', '$waktu_sekarang', '$telat', '$kategori_telat', '$poin', 'hadir', NULL, 'belum')";
            
            if (mysqli_query($conn, $query)) {
                // ========== KIRIM NOTIFIKASI WA KE GRUP ==========
                if ($telat > 0 && $wa_enabled == 'true' && !empty($wa_group_id)) {
                    $pesanWA = "📢 *INFORMASI ABSENSI SEKOLAH*\n\n";
                    $pesanWA .= "Yth. Para Orang Tua/Wali\n\n";
                    $pesanWA .= "Siswa *" . $siswa['nama'] . "* (Kelas: " . $siswa['kelas'] . ")\n";
                    $pesanWA .= "telah *MELAKUKAN ABSEN MASUK* pada:\n";
                    $pesanWA .= "🕐 Waktu: " . date('H:i:s') . " WIB\n";
                    $pesanWA .= "📅 Tanggal: " . date('d-m-Y') . "\n\n";
                    $pesanWA .= "⚠️ *STATUS: TERLAMBAT*\n";
                    $pesanWA .= "⏰ Keterlambatan: " . $telat_data['format'] . "\n";
                    $pesanWA .= "📊 Kategori: " . $kategori_telat . "\n";
                    $pesanWA .= "🔴 Poin Pelanggaran: " . $poin . "\n\n";
                    $pesanWA .= "Mohon perhatikan kedisiplinan putra/putri Anda.\n\n";
                    $pesanWA .= "*Sistem Absensi SekolahBISA!*";
                    
                    // Kirim ke grup WhatsApp
                    $curl = curl_init();
                    curl_setopt_array($curl, array(
                        CURLOPT_URL => 'https://api.fonnte.com/send',
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_POST => true,
                        CURLOPT_POSTFIELDS => array(
                            'target' => $wa_group_id,
                            'message' => $pesanWA,
                        ),
                        CURLOPT_HTTPHEADER => array('Authorization: ' . $api_key),
                    ));
                    
                    $response = curl_exec($curl);
                    curl_close($curl);
                    
                    echo "\n📱 Notifikasi telah dikirim ke grup WhatsApp";
                }
                // ========== END KIRIM WA KE GRUP ==========
                
                if ($telat > 0) {
                    echo "⚠️ ABSEN MASUK - " . $siswa['nama'] . "\n";
                    echo "🕐 Waktu: " . date('H:i:s') . " WIB\n";
                    echo "⏰ Terlambat: " . $telat_data['format'] . " (" . $telat . " menit)\n";
                    echo "📊 Kategori: " . $kategori_telat . "\n";
                    echo "🔴 Poin Pelanggaran: " . $poin;
                    if (!empty($wa_group_id)) echo "\n📱 Notifikasi telah dikirim ke grup WhatsApp";
                } else {
                    echo "✅ ABSEN MASUK - " . $siswa['nama'] . "\n";
                    echo "🕐 Waktu: " . date('H:i:s') . " WIB (Tepat Waktu)";
                }
            } else {
                echo "❌ Gagal menyimpan: " . mysqli_error($conn);
            }
        } else {
            // ABSEN PULANG
            $absen = mysqli_fetch_assoc($cekAbsen);
            
            if ($absen['status_pulang'] == 'sudah') {
                echo "⚠️ " . $siswa['nama'] . " sudah melakukan absen PULANG";
            } else {
                $update = "UPDATE absensi SET waktu_pulang = '$waktu_sekarang', status_pulang = 'sudah' 
                           WHERE siswa_id = $siswa_id AND tanggal = '$tanggal'";
                
                if (mysqli_query($conn, $update)) {
                    echo "✅ ABSEN PULANG - " . $siswa['nama'] . "\n";
                    echo "🕐 Waktu: " . date('H:i:s') . " WIB";
                } else {
                    echo "❌ Gagal update absen pulang: " . mysqli_error($conn);
                }
            }
        }
    } else {
        echo "Format QR tidak lengkap.";
    }
} else {
    echo "QR Code tidak dikenali (format harus ABSEN|ID|username)";
}
?>