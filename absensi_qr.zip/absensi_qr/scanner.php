<?php
session_start();
include 'config/database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Scanner QR Code - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://unpkg.com/html5-qrcode@2.3.8/html5-qrcode.min.js"></script>
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/scanner.css">
</head>
<body>
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="shape shape-3"></div>

    <div class="container">
        <div class="scanner-card">
            <div class="scanner-header">
                <div class="scanner-icon">
                    <i class="bi bi-upc-scan"></i>
                </div>
                <h4 class="mb-0 text-white">Scanner QR Code</h4>
                <small class="text-white-50">Arahkan kamera ke QR Code siswa</small>
            </div>
            
            <div class="scanner-body">
                <!-- Info Petunjuk -->
                <div class="alert alert-info mb-3 rounded-4 py-2">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    <small>Scan pertama → Absen Masuk | Scan kedua → Absen Pulang</small>
                </div>
                
                <!-- Scanner Area -->
                <div class="scanning-overlay" id="scanningOverlay">
                    <div id="reader"></div>
                    <div class="scan-line" id="scanLine"></div>
                </div>
                
                <!-- Camera Selector -->
                <div class="camera-selector">
                    <select id="cameraSelect" class="form-select-custom w-100">
                        <option value="">Mengakses kamera...</option>
                    </select>
                </div>
                
                <!-- Result Box -->
                <div id="result" class="result-box result-info">
                    <i class="bi bi-info-circle-fill"></i>
                    <div class="result-text">Menunggu scan QR Code...</div>
                    <div class="sound-wave" id="soundWave" style="display: none;">
                        <span></span><span></span><span></span><span></span><span></span>
                    </div>
                </div>
                
                <!-- Buttons -->
                <div class="d-flex gap-3 mt-4">
                    <a href="dashboard.php" class="btn-back">
                        <i class="bi bi-arrow-left"></i> Kembali
                    </a>
                    <button onclick="resetScanner()" class="btn-reset">
                        <i class="bi bi-arrow-repeat"></i> Reset
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        let html5QrCode = null;
        let currentCameraId = null;
        let isScanning = false;
        
        // Fungsi untuk menampilkan pesan
        function showMessage(message, type) {
            const resultDiv = $('#result');
            resultDiv.removeClass('result-success result-error result-warning result-info');
            
            let icon = '';
            switch(type) {
                case 'success':
                    resultDiv.addClass('result-success');
                    icon = '<i class="bi bi-check-circle-fill"></i>';
                    break;
                case 'error':
                    resultDiv.addClass('result-error');
                    icon = '<i class="bi bi-x-circle-fill"></i>';
                    break;
                case 'warning':
                    resultDiv.addClass('result-warning');
                    icon = '<i class="bi bi-exclamation-triangle-fill"></i>';
                    break;
                default:
                    resultDiv.addClass('result-info');
                    icon = '<i class="bi bi-info-circle-fill"></i>';
            }
            
            resultDiv.html(icon + '<div class="result-text">' + message + '</div><div class="sound-wave" style="display: none;"><span></span><span></span><span></span><span></span><span></span></div>');
            
            // Sound wave effect for success
            if (type === 'success') {
                const wave = resultDiv.find('.sound-wave');
                wave.css('display', 'inline-flex');
                setTimeout(() => {
                    wave.fadeOut(300);
                }, 2000);
            }
        }
        
        // Fungsi untuk reset scanner
        function resetScanner() {
            if (html5QrCode && html5QrCode.isScanning) {
                html5QrCode.stop().then(() => {
                    showMessage('Scanner direset, pilih kamera...', 'info');
                    startScannerWithSelectedCamera();
                }).catch(err => {
                    console.error('Error stop scanner:', err);
                    startScannerWithSelectedCamera();
                });
            } else {
                startScannerWithSelectedCamera();
            }
        }
        
        // Fungsi untuk memulai scanner dengan kamera yang dipilih
        function startScannerWithSelectedCamera() {
            const cameraId = $('#cameraSelect').val();
            if (!cameraId) return;
            
            if (html5QrCode && html5QrCode.isScanning) {
                html5QrCode.stop().then(() => {
                    initScanner(cameraId);
                }).catch(() => initScanner(cameraId));
            } else {
                initScanner(cameraId);
            }
        }
        
        // Inisialisasi scanner
        function initScanner(cameraId) {
            if (html5QrCode) {
                try {
                    html5QrCode.clear();
                } catch(e) {}
            }
            
            html5QrCode = new Html5Qrcode("reader");
            const config = { fps: 10, qrbox: { width: 280, height: 280 } };
            
            html5QrCode.start({ deviceId: { exact: cameraId } }, config, onScanSuccess, onScanError)
                .then(() => {
                    isScanning = true;
                    showMessage('Scanner siap, arahkan ke QR Code', 'info');
                })
                .catch(err => {
                    console.error('Gagal start kamera:', err);
                    showMessage('Gagal mengakses kamera: ' + err.message, 'error');
                    isScanning = false;
                });
        }
        
        // Fungsi saat scan berhasil
        function onScanSuccess(decodedText, decodedResult) {
            if (!isScanning) return;
            
            console.log('Scan result:', decodedText);
            showMessage('Memproses absensi...', 'info');
            
            $.ajax({
                url: 'proses_absen.php',
                type: 'POST',
                data: { qr_data: decodedText },
                timeout: 10000,
                success: function(response) {
                    if (response.includes('MASUK')) {
                        showMessage('✅ ' + response, 'success');
                    } else if (response.includes('PULANG')) {
                        showMessage('🚪 ' + response, 'success');
                    } else if (response.includes('sudah')) {
                        showMessage('⚠️ ' + response, 'warning');
                    } else if (response.includes('Berhasil')) {
                        showMessage('✅ ' + response, 'success');
                    } else {
                        showMessage('❌ ' + response, 'error');
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX Error:', status, error);
                    showMessage('❌ Gagal terhubung ke server: ' + status, 'error');
                }
            });
        }
        
        function onScanError(errorMessage) {
            // Tidak ditampilkan ke user
            console.log('Scan error:', errorMessage);
        }
        
        // Load daftar kamera
        function loadCameras() {
            Html5Qrcode.getCameras().then(cameras => {
                const select = $('#cameraSelect');
                select.empty();
                
                if (cameras && cameras.length > 0) {
                    cameras.forEach((camera, index) => {
                        const cameraName = camera.label || `Kamera ${index + 1}`;
                        const cameraType = index === 0 ? ' (Depan)' : (index === 1 ? ' (Belakang)' : '');
                        select.append(`<option value="${camera.id}">📷 ${cameraName}${cameraType}</option>`);
                    });
                    
                    // Default ke kamera belakang (index 1) atau kamera pertama
                    const defaultCamera = cameras.length > 1 ? cameras[1].id : cameras[0].id;
                    select.val(defaultCamera);
                    currentCameraId = defaultCamera;
                    initScanner(defaultCamera);
                } else {
                    select.append('<option value="">Tidak ada kamera ditemukan</option>');
                    showMessage('Tidak ada kamera yang terdeteksi!', 'error');
                }
            }).catch(err => {
                console.error('Error loading cameras:', err);
                $('#cameraSelect').html('<option value="">Error akses kamera</option>');
                showMessage('Gagal mengakses kamera: ' + err.message, 'error');
            });
        }
        
        // Event ganti kamera
        $(document).ready(function() {
            loadCameras();
            
            $('#cameraSelect').on('change', function() {
                const cameraId = $(this).val();
                if (cameraId && cameraId !== currentCameraId) {
                    currentCameraId = cameraId;
                    resetScanner();
                }
            });
        });
    </script>
</body>
</html>