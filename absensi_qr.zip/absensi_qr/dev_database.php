<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

// Cek login dan role
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'developer') {
    header("Location: index.php");
    exit();
}

// Ambil statistik database
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users"))['total'];
$total_guru = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 'guru'"))['total'];
$total_siswa_user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM users WHERE role = 'siswa'"))['total'];
$total_siswa_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM siswa"))['total'];
$total_absensi = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM absensi"))['total'];
$total_riwayat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as total FROM riwayat_poin"))['total'];

// Ambil daftar tabel
$tables = [];
$query_tables = mysqli_query($conn, "SHOW TABLES");
while ($row = mysqli_fetch_row($query_tables)) {
    $tables[] = $row[0];
}

// Proses backup
$backup_message = '';
if (isset($_POST['backup'])) {
    $backup_data = "-- Backup Database absensi_qr\n";
    $backup_data .= "-- Tanggal: " . date('Y-m-d H:i:s') . "\n\n";
    
    foreach ($tables as $table) {
        $query = mysqli_query($conn, "SELECT * FROM $table");
        $backup_data .= "-- Struktur tabel: $table\n";
        
        $create = mysqli_query($conn, "SHOW CREATE TABLE $table");
        $create_row = mysqli_fetch_row($create);
        $backup_data .= $create_row[1] . ";\n\n";
        
        $backup_data .= "-- Data tabel: $table\n";
        while ($row = mysqli_fetch_assoc($query)) {
            $backup_data .= "INSERT INTO $table VALUES (";
            $values = [];
            foreach ($row as $value) {
                $values[] = "'" . addslashes($value) . "'";
            }
            $backup_data .= implode(", ", $values) . ");\n";
        }
        $backup_data .= "\n";
    }
    
    $filename = "backup_absensi_" . date('Y-m-d_H-i-s') . ".sql";
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo $backup_data;
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Manager - Developer Panel</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/dev_database.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="text-white fw-bold">
                    <i class="bi bi-database-fill me-2 text-warning"></i> Database Manager
                </h2>
                <p class="text-white-50 mb-0">Kelola dan backup database</p>
            </div>
            <a href="dashboard_developer.php" class="btn-back">
                <i class="bi bi-arrow-left"></i> Kembali
            </a>
        </div>
        
        <!-- Statistik Cards -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_users ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_guru ?></div>
                    <div class="stat-label">Guru</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_siswa_data ?></div>
                    <div class="stat-label">Siswa (Data)</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_absensi ?></div>
                    <div class="stat-label">Absensi</div>
                </div>
            </div>
        </div>
        
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_siswa_user ?></div>
                    <div class="stat-label">Siswa (Akun)</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-number"><?= $total_riwayat ?></div>
                    <div class="stat-label">Riwayat Poin</div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card">
                    <div class="stat-number"><?= count($tables) ?></div>
                    <div class="stat-label">Jumlah Tabel</div>
                </div>
            </div>
        </div>
        
        <!-- Backup Section -->
        <div class="dev-card mb-4">
            <div class="p-4 border-bottom" style="border-color: rgba(255,255,255,0.1) !important;">
                <h5 class="text-white fw-semibold mb-0">
                    <i class="bi bi-cloud-arrow-up me-2 text-success"></i> Backup Database
                </h5>
            </div>
            <div class="p-4">
                <p class="text-white-50 mb-3">Download backup database dalam format SQL. Gunakan untuk menjaga keamanan data.</p>
                <form method="post">
                    <button type="submit" name="backup" class="btn btn-backup text-white">
                        <i class="bi bi-download"></i> Download Backup SQL
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Daftar Tabel -->
        <div class="dev-card">
            <div class="p-4 border-bottom" style="border-color: rgba(255,255,255,0.1) !important;">
                <h5 class="text-white fw-semibold mb-0">
                    <i class="bi bi-table me-2 text-info"></i> Daftar Tabel Database
                </h5>
            </div>
            <div class="p-4">
                <div class="table-responsive">
                    <table class="table table-dev">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Tabel</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; foreach ($tables as $table): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= $table ?></td>
                                <td>
                                    <a href="phpmyadmin" target="_blank" class="btn btn-sm btn-outline-light rounded-pill">
                                        <i class="bi bi-eye"></i> Lihat
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center mt-4">
            <small class="text-white-50">
                <i class="bi bi-shield-check"></i> Developer Mode - Database Management
            </small>
        </div>
    </div>
</body>
</html>