<?php
session_start();
include 'config/database.php';

// Update semua siswa dengan stella >= 8
mysqli_query($conn, "UPDATE siswa SET gelar = 'Imperial Scholar' WHERE stella >= 8");
mysqli_query($conn, "UPDATE siswa SET gelar = '' WHERE stella < 8 AND gelar = 'Imperial Scholar'");

// Update status blokir
mysqli_query($conn, "UPDATE siswa SET status_blokir = 'diblokir', alasan_blokir = 'Tonitrus mencapai 8 poin - Dikeluarkan' WHERE tonitrus >= 8");
mysqli_query($conn, "UPDATE siswa SET status_blokir = 'peringatan', alasan_blokir = 'Tonitrus mencapai 7 poin - Peringatan terakhir' WHERE tonitrus >= 7 AND tonitrus < 8");
mysqli_query($conn, "UPDATE siswa SET status_blokir = 'aktif', alasan_blokir = NULL WHERE tonitrus < 7");

echo "Semua gelar dan status berhasil diupdate!";
echo "<br><a href='dashboard.php'>Kembali ke Dashboard</a>";
?>