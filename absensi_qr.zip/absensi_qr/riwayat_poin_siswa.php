<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'siswa') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data siswa
$query_siswa = "SELECT s.id, s.nama, s.stella, s.tonitrus, s.total_poin 
                FROM siswa s 
                WHERE s.user_id = $user_id";
$result_siswa = mysqli_query($conn, $query_siswa);

if (!$result_siswa) {
    die("Error query siswa: " . mysqli_error($conn));
}

$siswa = mysqli_fetch_assoc($result_siswa);

if (!$siswa) {
    die("Data siswa tidak ditemukan untuk user_id: " . $user_id);
}

// Ambil riwayat poin
$query_riwayat = "SELECT r.*, s.nama 
                  FROM riwayat_poin r 
                  JOIN siswa s ON r.siswa_id = s.id 
                  WHERE r.siswa_id = {$siswa['id']}
                  ORDER BY r.tanggal DESC, r.waktu DESC";
$result_riwayat = mysqli_query($conn, $query_riwayat);

// Cek apakah query berhasil
if (!$result_riwayat) {
    // Jika tabel belum ada, buat dulu
    $create_table = "CREATE TABLE IF NOT EXISTS riwayat_poin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        siswa_id INT NOT NULL,
        jenis ENUM('stella', 'tonitrus') NOT NULL,
        jumlah INT NOT NULL,
        alasan TEXT,
        tanggal DATE NOT NULL,
        waktu TIME NOT NULL,
        diberikan_oleh VARCHAR(100)
    )";
    mysqli_query($conn, $create_table);
    
    // Coba query lagi
    $result_riwayat = mysqli_query($conn, $query_riwayat);
}

$jumlah_riwayat = ($result_riwayat) ? mysqli_num_rows($result_riwayat) : 0;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Poin - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/riwayat_poin_siswa.css">
</head>
<body>
    <div class="riwayat-card">
        <div class="text-white p-4" style="background: linear-gradient(135deg, #1e1b4b, #312e81);">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h4 class="mb-1 fw-bold">
                        <i class="bi bi-clock-history me-2"></i> Riwayat Poin
                    </h4>
                    <p class="mb-0 opacity-75"><?= htmlspecialchars($siswa['nama']) ?></p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill mt-2 mt-sm-0">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <!-- Ringkasan Poin -->
            <div class="row g-3 mb-4">
                <div class="col-4">
                    <div class="text-center p-3 rounded-3" style="background: linear-gradient(135deg, #fef3c7, #fde68a);">
                        <i class="bi bi-star-fill text-warning fs-2"></i>
                        <h3 class="mb-0 fw-bold text-warning"><?= $siswa['stella'] ?? 0 ?></h3>
                        <small>⭐ Stella</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="text-center p-3 rounded-3" style="background: linear-gradient(135deg, #fee2e2, #fecaca);">
                        <i class="bi bi-lightning-charge-fill text-danger fs-2"></i>
                        <h3 class="mb-0 fw-bold text-danger"><?= $siswa['tonitrus'] ?? 0 ?></h3>
                        <small>⚡ Tonitrus</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="text-center p-3 rounded-3" style="background: linear-gradient(135deg, #e0e7ff, #c7d2fe);">
                        <i class="bi bi-calculator-fill text-primary fs-2"></i>
                        <h3 class="mb-0 fw-bold text-primary"><?= $siswa['total_poin'] ?? 0 ?></h3>
                        <small>📊 Total Poin</small>
                    </div>
                </div>
            </div>
            
            <!-- Tabel Riwayat -->
            <h5 class="fw-semibold mb-3">
                <i class="bi bi-list-ul me-2"></i> Riwayat Perolehan Poin
            </h5>
            
            <?php if ($jumlah_riwayat > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Tanggal</th>
                                <th>Jenis</th>
                                <th>Jumlah</th>
                                <th>Alasan</th>
                                <th>Diberikan Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result_riwayat)): ?>
                                <tr>
                                    <td>
                                        <?= date('d-m-Y', strtotime($row['tanggal'])) ?>
                                        <br>
                                        <small class="text-muted"><?= substr($row['waktu'], 0, 5) ?> WIB</small>
                                    </td>
                                    <td>
                                        <?php if ($row['jenis'] == 'stella'): ?>
                                            <span class="badge bg-warning text-dark px-3 py-2 rounded-pill">
                                                <i class="bi bi-star-fill"></i> Stella
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger px-3 py-2 rounded-pill">
                                                <i class="bi bi-lightning-charge-fill"></i> Tonitrus
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="fw-bold">+<?= $row['jumlah'] ?> </td>
                                    <td><?= htmlspecialchars($row['alasan']) ?> </td>
                                    <td><?= htmlspecialchars($row['diberikan_oleh'] ?? 'Sistem') ?> </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
                    <p class="mt-3">Belum ada riwayat poin</p>
                    <small>Poin akan muncul saat Anda mendapat Stella ⭐ atau Tonitrus ⚡</small>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>