<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

// DEBUG: Cek session (hapus setelah berhasil)
// echo "<pre>Session: "; print_r($_SESSION); echo "</pre>";

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    // Jika belum login, redirect ke halaman login
    header("Location: index.php");
    exit();
}

// Cek apakah role-nya siswa
if ($_SESSION['role'] != 'siswa') {
    echo "<div class='alert alert-danger'>Akses ditolak. Halaman ini hanya untuk siswa.</div>";
    echo "<a href='dashboard.php'>Kembali ke Dashboard</a>";
    exit();
}

$user_id = $_SESSION['user_id'];
$today = date('Y-m-d');

// Ambil data siswa
$query_siswa = "SELECT s.id, s.nama, s.kelas FROM siswa s WHERE s.user_id = $user_id";
$result_siswa = mysqli_query($conn, $query_siswa);

if (!$result_siswa || mysqli_num_rows($result_siswa) == 0) {
    die("Error: Data siswa tidak ditemukan. User ID: " . $user_id);
}

$siswa = mysqli_fetch_assoc($result_siswa);
$siswa_id = $siswa['id'];
$nama_siswa = $siswa['nama'];

// Cek apakah sudah absen hari ini
$cek_absen = mysqli_query($conn, "SELECT * FROM absensi WHERE siswa_id = $siswa_id AND tanggal = '$today'");
$sudah_absen = mysqli_num_rows($cek_absen) > 0;
$data_absen = mysqli_fetch_assoc($cek_absen);

// Proses pengajuan izin/sakit
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['ajukan'])) {
    $status = $_POST['status'];
    $keterangan = mysqli_real_escape_string($conn, $_POST['keterangan']);
    
    // Upload file bukti
    $bukti_file = '';
    if (isset($_FILES['bukti']) && $_FILES['bukti']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'pdf'];
        $filename = $_FILES['bukti']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        
        if (in_array($ext, $allowed)) {
            $bukti_file = 'uploads/bukti/' . date('Ymd_His') . '_' . $siswa_id . '.' . $ext;
            $upload_dir = 'uploads/bukti/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            move_uploaded_file($_FILES['bukti']['tmp_name'], $bukti_file);
        } else {
            $error = "Format file tidak didukung. Gunakan JPG, PNG, atau PDF.";
        }
    } else if ($_FILES['bukti']['error'] != 4) {
        $error = "Gagal upload file. Silakan coba lagi.";
    }
    
    if (empty($error)) {
        if ($sudah_absen) {
            // Update absen yang sudah ada
            $update = "UPDATE absensi SET status = '$status', keterangan = '$keterangan', 
                       bukti_file = '$bukti_file', status_verifikasi = 'pending' 
                       WHERE siswa_id = $siswa_id AND tanggal = '$today'";
            if (mysqli_query($conn, $update)) {
                $message = "Pengajuan $status berhasil dikirim! Menunggu verifikasi guru.";
            } else {
                $error = "Gagal mengupdate: " . mysqli_error($conn);
            }
        } else {
            // Buat absen baru
            $insert = "INSERT INTO absensi (siswa_id, tanggal, waktu, status, keterangan, bukti_file, status_verifikasi) 
                       VALUES ('$siswa_id', '$today', NOW(), '$status', '$keterangan', '$bukti_file', 'pending')";
            if (mysqli_query($conn, $insert)) {
                $message = "Pengajuan $status berhasil dikirim! Menunggu verifikasi guru.";
            } else {
                $error = "Gagal menyimpan: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Izin/Sakit - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/ajukan_izin.css">
</head>
<body>
    <div class="form-card">
        <div class="card-header-custom text-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1 fw-bold"><i class="bi bi-file-earmark-text me-2"></i> Ajukan Izin/Sakit</h4>
                    <p class="mb-0 opacity-75">Pengajuan ketidakhadiran dengan bukti</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <!-- Informasi Siswa -->
            <div class="info-card mb-4">
                <div class="d-flex align-items-center gap-3">
                    <i class="bi bi-person-circle" style="font-size: 32px; color: #22c55e;"></i>
                    <div>
                        <h6 class="mb-0 fw-bold"><?= htmlspecialchars($nama_siswa) ?></h6>
                        <small class="text-muted">Kelas: <?= htmlspecialchars($siswa['kelas']) ?></small>
                    </div>
                </div>
            </div>
            
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Info Status Saat Ini -->
            <?php if ($sudah_absen): ?>
                <div class="alert alert-info mb-4">
                    <i class="bi bi-info-circle-fill me-2"></i>
                    Anda sudah melakukan absensi hari ini dengan status: 
                    <strong><?= ucfirst($data_absen['status']) ?></strong>
                    <?php if (isset($data_absen['status_verifikasi']) && $data_absen['status_verifikasi'] == 'pending'): ?>
                        <br><small class="text-warning">⏳ Menunggu verifikasi guru</small>
                    <?php elseif (isset($data_absen['status_verifikasi']) && $data_absen['status_verifikasi'] == 'disetujui'): ?>
                        <br><small class="text-success">✅ Telah diverifikasi</small>
                    <?php elseif (isset($data_absen['status_verifikasi']) && $data_absen['status_verifikasi'] == 'ditolak'): ?>
                        <br><small class="text-danger">❌ Ditolak, silakan ajukan ulang</small>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <!-- Form Pengajuan -->
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Jenis Pengajuan</label>
                    <select name="status" class="form-select rounded-pill" required>
                        <option value="izin">📝 Izin (kepentingan keluarga, acara, dll)</option>
                        <option value="sakit">🤒 Sakit</option>
                    </select>
                </div>
                
                <div class="mb-3">
                    <label class="form-label fw-semibold">Keterangan</label>
                    <textarea name="keterangan" class="form-control rounded-3" rows="3" 
                              placeholder="Contoh: Ada acara keluarga / Sakit demam / ..." required></textarea>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-semibold">Upload Bukti (Surat Izin/Sakit)</label>
                    <div class="file-upload" onclick="document.getElementById('fileInput').click()">
                        <i class="bi bi-cloud-upload" style="font-size: 40px; color: #667eea;"></i>
                        <p class="mb-0 mt-2">Klik untuk upload file</p>
                        <small class="text-muted">Format: JPG, PNG, PDF (Max 5MB)</small>
                    </div>
                    <input type="file" name="bukti" id="fileInput" class="d-none" accept=".jpg,.jpeg,.png,.pdf">
                    <div id="fileName" class="mt-2 text-center small text-muted"></div>
                </div>
                
                <button type="submit" name="ajukan" class="btn btn-submit text-white w-100">
                    <i class="bi bi-send me-2"></i> Ajukan Izin/Sakit
                </button>
            </form>
            
            <hr class="my-4">
            
            <div class="text-center">
                <small class="text-muted">
                    <i class="bi bi-info-circle"></i> 
                    Pengajuan akan diverifikasi oleh guru. Pastikan bukti surat jelas dan terbaca.
                </small>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('fileInput').addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name;
            document.getElementById('fileName').innerHTML = fileName ? `📎 ${fileName}` : '';
        });
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>