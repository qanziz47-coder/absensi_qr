<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header("Location: index.php");
    exit();
}

$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('Y-m');
$filter_kelas = isset($_GET['kelas']) ? $_GET['kelas'] : '';

// Ambil daftar kelas unik untuk dropdown
$query_kelas = "SELECT DISTINCT kelas FROM siswa ORDER BY kelas";
$result_kelas = mysqli_query($conn, $query_kelas);
$kelas_list = [];
while ($row = mysqli_fetch_assoc($result_kelas)) {
    $kelas_list[] = $row['kelas'];
}

// Build query dengan filter
$where_conditions = ["DATE_FORMAT(a.tanggal, '%Y-%m') = '$filter_bulan'"];
if (!empty($filter_kelas)) {
    $where_conditions[] = "s.kelas = '$filter_kelas'";
}
$where_clause = "WHERE " . implode(" AND ", $where_conditions);

// Query data rekap keterlambatan
$query = "SELECT s.nama, s.kelas, 
                 COUNT(a.id) as total_hadir,
                 SUM(CASE WHEN a.telat > 0 THEN 1 ELSE 0 END) as total_telat,
                 SUM(a.telat) as total_menit_telat,
                 SUM(a.poin) as total_poin
          FROM absensi a 
          JOIN siswa s ON a.siswa_id = s.id 
          $where_clause
          GROUP BY a.siswa_id
          ORDER BY total_menit_telat DESC";
$result = mysqli_query($conn, $query);

// Hitung statistik keseluruhan
$total_siswa = 0;
$total_siswa_telat = 0;
$total_menit_keseluruhan = 0;
$total_poin_keseluruhan = 0;
$siswa_terbanyak_telat = '';
$menit_terbanyak = 0;

$data_siswa = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data_siswa[] = $row;
    $total_siswa++;
    if ($row['total_menit_telat'] > 0) {
        $total_siswa_telat++;
        $total_menit_keseluruhan += $row['total_menit_telat'];
        $total_poin_keseluruhan += $row['total_poin'];
        if ($row['total_menit_telat'] > $menit_terbanyak) {
            $menit_terbanyak = $row['total_menit_telat'];
            $siswa_terbanyak_telat = $row['nama'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Keterlambatan - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/rekap_telat.css">
</head>
<body>
    <div class="main-card animate-fade-in">
        <!-- Header -->
        <div class="card-header-gradient text-white">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <h2 class="mb-1 fw-bold">
                        <i class="bi bi-clock-history me-2"></i> Rekap Keterlambatan
                    </h2>
                    <p class="mb-0 opacity-75">Data keterlambatan siswa per bulan</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill mt-2 mt-sm-0">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <!-- Filter Box -->
            <div class="filter-box">
                <form method="get" class="row g-3 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label fw-semibold text-muted">
                            <i class="bi bi-calendar3 me-1"></i> Pilih Bulan
                        </label>
                        <input type="month" name="bulan" class="form-control rounded-pill" value="<?= $filter_bulan ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-semibold text-muted">
                            <i class="bi bi-building me-1"></i> Filter Kelas
                        </label>
                        <select name="kelas" class="form-select rounded-pill">
                            <option value="">Semua Kelas</option>
                            <?php foreach ($kelas_list as $kelas): ?>
                                <option value="<?= htmlspecialchars($kelas) ?>" <?= $filter_kelas == $kelas ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($kelas) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-filter text-white w-100">
                            <i class="bi bi-search me-1"></i> Filter
                        </button>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <span class="text-muted">
                            <i class="bi bi-info-circle me-1"></i>
                            <?php 
                            $filter_info = [];
                            $filter_info[] = "Bulan: " . date('F Y', strtotime($filter_bulan . '-01'));
                            if (!empty($filter_kelas)) $filter_info[] = "Kelas: " . htmlspecialchars($filter_kelas);
                            echo implode(" | ", $filter_info);
                            ?>
                        </span>
                        <?php if (!empty($filter_kelas)): ?>
                            <a href="rekap_telat.php?bulan=<?= $filter_bulan ?>" class="btn btn-sm btn-outline-secondary rounded-pill ms-2">
                                <i class="bi bi-eraser"></i> Reset Kelas
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
            
            <!-- Statistik Cards -->
            <div class="row g-4 mb-4">
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Siswa</p>
                                <p class="stat-value"><?= $total_siswa ?></p>
                            </div>
                            <div class="stat-icon" style="background: linear-gradient(135deg, #667eea20, #764ba220); color: #667eea;">
                                <i class="bi bi-people-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Siswa Terlambat</p>
                                <p class="stat-value text-warning"><?= $total_siswa_telat ?></p>
                            </div>
                            <div class="stat-icon" style="background: #f59e0b20; color: #f59e0b;">
                                <i class="bi bi-exclamation-triangle-fill"></i>
                            </div>
                        </div>
                        <div class="mt-2">
                            <div class="progress" style="height: 4px;">
                                <div class="progress-bar bg-warning" style="width: <?= $total_siswa > 0 ? ($total_siswa_telat / $total_siswa) * 100 : 0 ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Menit Telat</p>
                                <p class="stat-value text-danger"><?= $total_menit_keseluruhan ?></p>
                            </div>
                            <div class="stat-icon" style="background: #ef444420; color: #ef4444;">
                                <i class="bi bi-clock-history"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="stat-card">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <p class="stat-label">Total Poin</p>
                                <p class="stat-value text-danger"><?= $total_poin_keseluruhan ?></p>
                            </div>
                            <div class="stat-icon" style="background: #ef444420; color: #ef4444;">
                                <i class="bi bi-lightning-charge-fill"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Peringatan jika ada siswa dengan telat tinggi -->
            <?php if ($menit_terbanyak > 60): ?>
                <div class="alert alert-danger alert-dismissible fade show rounded-4 mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <strong>Peringatan!</strong> <?= htmlspecialchars($siswa_terbanyak_telat) ?> memiliki total keterlambatan <?= $menit_terbanyak ?> menit bulan ini.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php elseif ($menit_terbanyak > 30): ?>
                <div class="alert alert-warning alert-dismissible fade show rounded-4 mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <strong>Perhatian!</strong> <?= htmlspecialchars($siswa_terbanyak_telat) ?> memiliki total keterlambatan <?= $menit_terbanyak ?> menit bulan ini.
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <!-- Tabel Data -->
            <div class="card border-0 shadow-sm rounded-4">
                <div class="card-body p-0">
                    <div class="p-3 border-bottom bg-light rounded-top-4">
                        <h5 class="mb-0 fw-semibold">
                            <i class="bi bi-table me-2 text-primary"></i> Detail Keterlambatan Siswa
                            <?php if (!empty($filter_kelas)): ?>
                                <span class="badge bg-primary ms-2"><?= htmlspecialchars($filter_kelas) ?></span>
                            <?php endif; ?>
                        </h5>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-modern mb-0">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    <th class="text-center">Total Hadir</th>
                                    <th class="text-center">Frekuensi Telat</th>
                                    <th class="text-center">Total Menit</th>
                                    <th class="text-center">Total Poin</th>
                                    <th class="text-center">Rata-rata Telat</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (count($data_siswa) > 0): ?>
                                    <?php $no = 1; foreach ($data_siswa as $row): ?>
                                        <?php 
                                        $rata_rata = $row['total_hadir'] > 0 ? round($row['total_menit_telat'] / $row['total_hadir'], 1) : 0;
                                        if ($row['total_menit_telat'] > 60) {
                                            $status = '<span class="badge-telat-tinggi"><i class="bi bi-emoji-angry me-1"></i> Sangat Tinggi</span>';
                                        } elseif ($row['total_menit_telat'] > 30) {
                                            $status = '<span class="badge-telat-sedang"><i class="bi bi-emoji-frown me-1"></i> Tinggi</span>';
                                        } elseif ($row['total_menit_telat'] > 0) {
                                            $status = '<span class="badge-telat-rendah"><i class="bi bi-emoji-smile me-1"></i> Ringan</span>';
                                        } else {
                                            $status = '<span class="badge-telat-rendah"><i class="bi bi-check-circle-fill me-1"></i> Disiplin</span>';
                                        }
                                        ?>
                                        <tr class="<?= $row['total_menit_telat'] > 60 ? 'table-danger' : ($row['total_menit_telat'] > 30 ? 'table-warning' : '') ?>">
                                            <td class="fw-medium"><?= $no++ ?></td>
                                            <td class="fw-medium"><?= htmlspecialchars($row['nama']) ?></td>
                                            <td class="text-center"><?= htmlspecialchars($row['kelas']) ?></td>
                                            <td class="text-center"><?= $row['total_hadir'] ?> hari</td>
                                            <td class="text-center"><?= $row['total_telat'] ?>x</td>
                                            <td class="text-center fw-bold <?= $row['total_menit_telat'] > 60 ? 'text-danger' : ($row['total_menit_telat'] > 30 ? 'text-warning' : '') ?>">
                                                <?= $row['total_menit_telat'] ?> menit
                                            </td>
                                            <td class="text-center"><?= $row['total_poin'] ?></td>
                                            <td class="text-center"><?= $rata_rata ?> menit/hari</td>
                                            <td class="text-center"><?= $status ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="9" class="text-center py-5">
                                            <i class="bi bi-inbox" style="font-size: 64px; color: #cbd5e1;"></i>
                                            <p class="mt-3 text-muted">Belum ada data absensi untuk periode ini</p>
                                            <small>Silakan lakukan absensi terlebih dahulu</small>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
            <!-- Footer -->
            <div class="mt-4 text-center text-muted">
                <small>
                    <i class="bi bi-printer"></i> Laporan dihasilkan: <?= date('d-m-Y H:i:s') ?>
                </small>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>