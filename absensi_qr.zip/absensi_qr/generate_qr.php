<?php
session_start();
include 'config/database.php';

// Set zona waktu
date_default_timezone_set('Asia/Jakarta');

// Cek apakah yang login adalah guru
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'guru') {
    die("Akses ditolak. Hanya guru yang bisa mengakses halaman ini.");
}

// Buat folder qrcodes jika belum ada
$qr_dir = "assets/qrcodes/";
if (!file_exists($qr_dir)) {
    mkdir($qr_dir, 0777, true);
}

// Ambil data siswa
$query = "SELECT s.id, s.nama, u.username FROM siswa s JOIN users u ON s.user_id = u.id";
$result = mysqli_query($conn, $query);

// Cek apakah query berhasil
if (!$result) {
    die("Error query: " . mysqli_error($conn));
}

// Cek apakah ada siswa
$total_siswa = mysqli_num_rows($result);
$siswa_list = [];
$count = 0;
$errors = [];

if ($total_siswa == 0) {
    // Tampilkan error dengan desain modern
    $no_siswa = true;
} else {
    $no_siswa = false;
    while ($row = mysqli_fetch_assoc($result)) {
        $siswa_list[] = $row;
        $siswa_id = $row['id'];
        $nama_siswa = $row['nama'];
        
        // Data yang akan disimpan dalam QR Code
        $qr_data = "ABSEN|" . $siswa_id . "|" . $row['username'];
        $file_name = $qr_dir . "siswa_" . $siswa_id . ".png";
        
        $qr_success = false;
        
        // Method 1: Coba dengan phpqrcode jika ada
        if (file_exists('libs/phpqrcode/qrlib.php')) {
            include_once 'libs/phpqrcode/qrlib.php';
            try {
                QRcode::png($qr_data, $file_name, QR_ECLEVEL_H, 6);
                if (file_exists($file_name)) {
                    $qr_success = true;
                }
            } catch (Exception $e) {
                // Gagal, lanjut ke method lain
            }
        }
        
        // Method 2: Gunakan Google Charts API (tidak perlu library)
        if (!$qr_success) {
            $qr_url = "https://quickchart.io/qr?text=" . urlencode($qr_data) . "&size=300&margin=2";
            $qr_image = @file_get_contents($qr_url);
            if ($qr_image !== false) {
                file_put_contents($file_name, $qr_image);
                if (file_exists($file_name)) {
                    $qr_success = true;
                }
            }
        }
        
        if ($qr_success) {
            $update = "UPDATE siswa SET qr_code = '$file_name' WHERE id = $siswa_id";
            mysqli_query($conn, $update);
            $count++;
        } else {
            $errors[] = $nama_siswa;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate QR Code - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/generate_qr.css">
</head>
<body>
    <div class="shape shape-1"></div>
    <div class="shape shape-2"></div>
    <div class="shape shape-3"></div>

    <div class="result-card">
        <?php if ($no_siswa): ?>
            <!-- Tidak ada siswa -->
            <div class="icon-container icon-warning">
                <i class="bi bi-exclamation-triangle-fill"></i>
            </div>
            <h3 class="result-title">Tidak Ada Data Siswa</h3>
            <p class="result-message">
                Belum ada data siswa di database. Silakan tambahkan siswa terlebih dahulu melalui phpMyAdmin.
            </p>
            <div class="stats-box">
                <div class="stat-number text-warning">0</div>
                <div class="stat-label">Total Siswa</div>
            </div>
            <a href="dashboard.php" class="btn btn-dashboard text-white text-decoration-none">
                <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
            </a>
            
        <?php elseif ($count == $total_siswa): ?>
            <!-- Sukses semua -->
            <div class="icon-container icon-success">
                <i class="bi bi-check-circle-fill"></i>
            </div>
            <h3 class="result-title">Generate QR Berhasil!</h3>
            <p class="result-message">
                Semua QR Code untuk siswa berhasil dibuat dan tersimpan di folder <strong>assets/qrcodes/</strong>
            </p>
            <div class="stats-box">
                <div class="row">
                    <div class="col-6">
                        <div class="stat-number text-success"><?= $count ?></div>
                        <div class="stat-label">QR Berhasil</div>
                    </div>
                    <div class="col-6">
                        <div class="stat-number text-muted">0</div>
                        <div class="stat-label">Gagal</div>
                    </div>
                </div>
            </div>
            <div class="progress-container">
                <div class="progress-label">Progress: 100%</div>
                <div class="progress-bar-custom">
                    <div class="progress-fill fill-success" style="width: 100%"></div>
                </div>
            </div>
            <div class="countdown">
                <i class="bi bi-hourglass-split"></i> Mengalihkan ke dashboard dalam 3 detik...
            </div>
            <a href="dashboard.php" class="btn btn-dashboard text-white text-decoration-none mt-2">
                <i class="bi bi-house"></i> Kembali Sekarang
            </a>
            
        <?php elseif ($count > 0 && count($errors) > 0): ?>
            <!-- Sebagian berhasil, sebagian gagal -->
            <div class="icon-container icon-info">
                <i class="bi bi-info-circle-fill"></i>
            </div>
            <h3 class="result-title">Generate QR Selesai</h3>
            <p class="result-message">
                Proses generate QR Code telah selesai dengan hasil sebagai berikut.
            </p>
            <div class="stats-box">
                <div class="row">
                    <div class="col-6">
                        <div class="stat-number text-success"><?= $count ?></div>
                        <div class="stat-label">QR Berhasil</div>
                    </div>
                    <div class="col-6">
                        <div class="stat-number text-danger"><?= count($errors) ?></div>
                        <div class="stat-label">Gagal</div>
                    </div>
                </div>
            </div>
            <div class="progress-container">
                <div class="progress-label">Progress: <?= round(($count / $total_siswa) * 100) ?>%</div>
                <div class="progress-bar-custom">
                    <div class="progress-fill fill-success" style="width: <?= ($count / $total_siswa) * 100 ?>%"></div>
                </div>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="error-list">
                    <h6><i class="bi bi-exclamation-triangle"></i> Gagal untuk siswa:</h6>
                    <ul>
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <small class="text-muted">Periksa koneksi internet dan coba lagi.</small>
                </div>
            <?php endif; ?>
            
            <div class="countdown mt-3">
                <i class="bi bi-hourglass-split"></i> Mengalihkan ke dashboard dalam 3 detik...
            </div>
            <a href="dashboard.php" class="btn btn-dashboard text-white text-decoration-none mt-2">
                <i class="bi bi-house"></i> Kembali Sekarang
            </a>
            
        <?php elseif ($count == 0 && count($errors) > 0): ?>
            <!-- Semua gagal -->
            <div class="icon-container icon-error">
                <i class="bi bi-x-circle-fill"></i>
            </div>
            <h3 class="result-title">Generate QR Gagal</h3>
            <p class="result-message">
                Tidak ada QR Code yang berhasil dibuat. Periksa koneksi internet Anda dan coba lagi.
            </p>
            <div class="stats-box">
                <div class="stat-number text-danger">0</div>
                <div class="stat-label">QR Berhasil</div>
            </div>
            <div class="error-list">
                <h6><i class="bi bi-exclamation-triangle"></i> Gagal untuk siswa:</h6>
                <ul>
                    <?php foreach ($errors as $err): ?>
                        <li><?= htmlspecialchars($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <a href="generate_qr.php" class="btn btn-dashboard text-white text-decoration-none">
                <i class="bi bi-arrow-repeat"></i> Coba Lagi
            </a>
            <a href="dashboard.php" class="btn btn-outline-secondary mt-2 text-decoration-none" style="border-radius: 50px;">
                <i class="bi bi-house"></i> Ke Dashboard
            </a>
        <?php endif; ?>
    </div>

    <!-- Auto redirect countdown -->
    <?php if (!$no_siswa && $count > 0): ?>
    <script>
        let seconds = 3;
        const countdownEl = document.querySelector('.countdown');
        if (countdownEl) {
            const interval = setInterval(() => {
                seconds--;
                if (seconds <= 0) {
                    clearInterval(interval);
                    window.location.href = 'dashboard.php';
                } else {
                    countdownEl.innerHTML = '<i class="bi bi-hourglass-split"></i> Mengalihkan ke dashboard dalam ' + seconds + ' detik...';
                }
            }, 1000);
        }
    </script>
    <?php endif; ?>
</body>
</html>