<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'siswa') {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT s.id, s.nama, s.kelas, s.stella, s.gelar, s.sertifikat_file 
          FROM siswa s 
          WHERE s.user_id = $user_id";
$result = mysqli_query($conn, $query);
$siswa = mysqli_fetch_assoc($result);

if ($siswa['gelar'] != 'Imperial Scholar') {
    echo "<div class='alert alert-danger'>Anda belum mencapai gelar Imperial Scholar! Kumpulkan 8 Stella terlebih dahulu.</div>";
    echo "<a href='dashboard.php' class='btn btn-primary'>Kembali</a>";
    exit();
}

// Include file generate sertifikat
if (file_exists('generate_sertifikat.php')) {
    include 'generate_sertifikat.php';
} else {
    // Jika file tidak ada, buat fungsi sederhana
    function generateSertifikat($conn, $siswa_id, $nama_siswa, $stella) {
        $output_dir = 'assets/sertifikat/';
        if (!file_exists($output_dir)) {
            mkdir($output_dir, 0777, true);
        }
        $output_file = $output_dir . 'sertifikat_' . $siswa_id . '_' . date('Ymd') . '.png';
        
        // Buat gambar sederhana
        $img = imagecreatetruecolor(1200, 850);
        $white = imagecolorallocate($img, 255, 255, 255);
        $gold = imagecolorallocate($img, 255, 215, 0);
        $black = imagecolorallocate($img, 0, 0, 0);
        
        imagefill($img, 0, 0, $white);
        imagerectangle($img, 10, 10, 1190, 840, $gold);
        imagestring($img, 5, 450, 300, "IMPERIAL SCHOLAR", $gold);
        imagestring($img, 5, 400, 400, $nama_siswa, $black);
        imagestring($img, 4, 500, 500, $stella . " Stella", $gold);
        
        imagepng($img, $output_file);
        imagedestroy($img);
        
        mysqli_query($conn, "UPDATE siswa SET sertifikat_file = '$output_file' WHERE id = $siswa_id");
        return $output_file;
    }
}

$sertifikat_file = $siswa['sertifikat_file'];
if (empty($sertifikat_file) || !file_exists($sertifikat_file)) {
    $sertifikat_file = generateSertifikat($conn, $siswa['id'], $siswa['nama'], $siswa['stella']);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sertifikat Imperial Scholar - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/sertifikat_imperial.css">
</head>
<body>
    <div class="certificate-container">
        <div class="certificate-card">
            <div class="crown-icon">👑</div>
            <h2 class="text-warning fw-bold mb-2">IMPERIAL SCHOLAR</h2>
            <p class="text-muted mb-4">CERTIFICATE OF ACHIEVEMENT</p>
            
            <img src="<?= $sertifikat_file ?>" alt="Sertifikat" class="certificate-img">
            
            <div class="mt-4">
                <p class="fw-semibold"><?= htmlspecialchars($siswa['nama']) ?></p>
                <p class="small text-muted">Telah mencapai <?= $siswa['stella'] ?> Stella</p>
            </div>
            
            <div class="mt-4 d-flex gap-3 justify-content-center no-print">
                <a href="<?= $sertifikat_file ?>" download class="btn-download">
                    <i class="bi bi-download"></i> Download Sertifikat (PNG)
                </a>
                <button onclick="window.print()" class="btn-download" style="background: #667eea; color: white;">
                    <i class="bi bi-printer"></i> Cetak
                </button>
                <a href="dashboard.php" class="btn-back">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
            
            <div class="mt-3 small text-muted no-print">
                <i class="bi bi-info-circle"></i> Sertifikat ini adalah bukti pencapaian gelar Imperial Scholar
            </div>
        </div>
    </div>
</body>
</html>