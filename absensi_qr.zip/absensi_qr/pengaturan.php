<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'guru') {
    header("Location: index.php");
    exit();
}

// Proses simpan pengaturan
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['simpan'])) {
    $jam_masuk = $_POST['jam_masuk'];
    $batas_ringan = (int)$_POST['batas_ringan'];
    $batas_sedang = (int)$_POST['batas_sedang'];
    $poin_ringan = (int)$_POST['poin_ringan'];
    $poin_sedang = (int)$_POST['poin_sedang'];
    $poin_berat = (int)$_POST['poin_berat'];
    
    // Update pengaturan
    $update1 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$jam_masuk' WHERE key_setting = 'jam_masuk'");
    $update2 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$batas_ringan' WHERE key_setting = 'batas_telat_ringan'");
    $update3 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$batas_sedang' WHERE key_setting = 'batas_telat_sedang'");
    $update4 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$poin_ringan' WHERE key_setting = 'poin_telat_ringan'");
    $update5 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$poin_sedang' WHERE key_setting = 'poin_telat_sedang'");
    $update6 = mysqli_query($conn, "UPDATE pengaturan SET value_setting = '$poin_berat' WHERE key_setting = 'poin_telat_berat'");
    
    if ($update1 && $update2 && $update3 && $update4 && $update5 && $update6) {
        $message = "Pengaturan berhasil disimpan!";
    } else {
        $error = "Gagal menyimpan pengaturan: " . mysqli_error($conn);
    }
}

// Ambil pengaturan saat ini
$settings = [];
$query = mysqli_query($conn, "SELECT * FROM pengaturan");
while ($row = mysqli_fetch_assoc($query)) {
    $settings[$row['key_setting']] = $row['value_setting'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan Absensi - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="icon" type="image/png" href="assets/favicon.png">
    <link rel="stylesheet" href="css/pengaturan.css">
</head>
<body>
    <div class="settings-card">
        <div class="card-header-custom text-white">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1 fw-bold"><i class="bi bi-gear-fill me-2"></i> Pengaturan Absensi</h4>
                    <p class="mb-0 opacity-75">Atur batas waktu keterlambatan dan poin pelanggaran</p>
                </div>
                <a href="dashboard.php" class="btn btn-outline-light rounded-pill">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
        
        <div class="p-4">
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="bi bi-check-circle-fill me-2"></i> <?= $message ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <form method="post">
                <!-- Jam Masuk Sekolah -->
                <div class="mb-4">
                    <label class="form-label fw-semibold">
                        <i class="bi bi-clock"></i> Jam Masuk Sekolah
                    </label>
                    <input type="time" name="jam_masuk" class="form-control form-control-custom" 
                           value="<?= $settings['jam_masuk'] ?? '07:00' ?>" required>
                    <small class="text-muted">Siswa yang absen setelah jam ini akan dianggap terlambat</small>
                </div>
                
                <hr class="my-4">
                
                <h5 class="fw-semibold mb-3"><i class="bi bi-hourglass-split"></i> Batas Keterlambatan</h5>
                
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Batas Telat Ringan</label>
                        <div class="input-group">
                            <input type="number" name="batas_ringan" class="form-control form-control-custom" 
                                   value="<?= $settings['batas_telat_ringan'] ?? 15 ?>" min="1" max="60" required>
                            <span class="input-group-text">menit</span>
                        </div>
                        <small class="text-muted">1 - <?= ($settings['batas_telat_sedang'] ?? 30) - 1 ?> menit = Telat Ringan</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label fw-semibold">Batas Telat Sedang</label>
                        <div class="input-group">
                            <input type="number" name="batas_sedang" class="form-control form-control-custom" 
                                   value="<?= $settings['batas_telat_sedang'] ?? 30 ?>" min="1" max="120" required>
                            <span class="input-group-text">menit</span>
                        </div>
                        <small class="text-muted"><?= ($settings['batas_telat_ringan'] ?? 15) + 1 ?> - <?= $settings['batas_telat_sedang'] ?? 30 ?> menit = Telat Sedang</small>
                    </div>
                </div>
                
                <hr class="my-4">
                
                <h5 class="fw-semibold mb-3"><i class="bi bi-exclamation-triangle"></i> Poin Pelanggaran</h5>
                
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Poin Telat Ringan</label>
                        <input type="number" name="poin_ringan" class="form-control form-control-custom" 
                               value="<?= $settings['poin_telat_ringan'] ?? 1 ?>" min="0" max="10" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Poin Telat Sedang</label>
                        <input type="number" name="poin_sedang" class="form-control form-control-custom" 
                               value="<?= $settings['poin_telat_sedang'] ?? 2 ?>" min="0" max="10" required>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label fw-semibold">Poin Telat Berat</label>
                        <input type="number" name="poin_berat" class="form-control form-control-custom" 
                               value="<?= $settings['poin_telat_berat'] ?? 3 ?>" min="0" max="10" required>
                    </div>
                </div>
                
                <!-- Preview -->
                <div class="preview-card">
                    <h6 class="fw-semibold mb-2"><i class="bi bi-eye"></i> Preview Kategori</h6>
                    <table class="table table-sm">
                        <thead>
                            <tr><th>Kategori</th><th>Keterlambatan</th><th>Poin</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Tepat Waktu</td><td>Sebelum jam masuk</td><td>0</td></tr>
                            <tr><td>Telat Ringan</td><td>1 - <?= $settings['batas_telat_ringan'] ?? 15 ?> menit</td><td><?= $settings['poin_telat_ringan'] ?? 1 ?></td></tr>
                            <tr><td>Telat Sedang</td><td><?= ($settings['batas_telat_ringan'] ?? 15) + 1 ?> - <?= $settings['batas_telat_sedang'] ?? 30 ?> menit</td><td><?= $settings['poin_telat_sedang'] ?? 2 ?></td></tr>
                            <tr><td>Telat Berat</td><td>&gt; <?= $settings['batas_telat_sedang'] ?? 30 ?> menit</td><td><?= $settings['poin_telat_berat'] ?? 3 ?></td></tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="d-grid gap-2 mt-4">
                    <button type="submit" name="simpan" class="btn btn-save text-white">
                        <i class="bi bi-save"></i> Simpan Pengaturan
                    </button>
                </div>
            </form>
            
            <div class="alert alert-info mt-4">
                <i class="bi bi-info-circle-fill me-2"></i>
                <strong>Informasi:</strong> Perubahan pengaturan akan langsung berlaku untuk absensi selanjutnya.
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>