<?php
session_start();
include 'config/database.php';
date_default_timezone_set('Asia/Jakarta');

// Cek login dan role
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

if ($_SESSION['role'] != 'developer') {
    header("Location: dashboard.php");
    exit();
}

$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Panel - SekolahBISA!</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/dashboard_developer.css">
</head>
<body>
    <div class="container">
        <!-- Navbar -->
        <div class="navbar-dev d-flex justify-content-between align-items-center flex-wrap">
            <div>
                <h4 class="text-white mb-0 fw-bold">
                    <i class="bi bi-shield-lock-fill me-2"></i> SekolahBISA! Developer
                </h4>
            </div>
            <div class="d-flex align-items-center gap-3 mt-2 mt-sm-0">
                <span class="text-white">
                    <i class="bi bi-person-circle me-1"></i> <?= htmlspecialchars($username) ?>
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm rounded-pill px-3">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
        
        <!-- Welcome Card -->
        <div class="welcome-card">
            <div class="d-flex justify-content-between align-items-center flex-wrap">
                <div>
                    <div class="badge-dev text-white d-inline-block mb-2">
                        <i class="bi bi-shield-check"></i> Super Admin Access
                    </div>
                    <h2 class="text-white mb-2 fw-bold">Selamat datang, Developer!</h2>
                    <p class="text-white-50 mb-0">Anda memiliki akses penuh ke sistem. Kelola pengaturan WhatsApp di sini.</p>
                </div>
                <div class="mt-3 mt-sm-0">
<a href="preview_guru.php" class="btn btn-outline-light rounded-pill" target="_blank">
    <i class="bi bi-eye"></i> Lihat Dashboard Guru
</a>
                </div>
            </div>
        </div>
        
        <!-- Menu Grid -->
        <div class="row g-4">
            <!-- Menu WhatsApp -->
            <div class="col-md-4">
                <div class="menu-dev-card">
                    <div class="menu-icon" style="background: rgba(37, 211, 102, 0.2); color: #25D366;">
                        <i class="bi bi-whatsapp"></i>
                    </div>
                    <h5 class="menu-title">WhatsApp Gateway</h5>
                    <p class="menu-desc">Kelola API Key dan ID Grup untuk notifikasi WhatsApp</p>
                    <a href="ortu_siswa.php" class="btn btn-success btn-dev">
                        <i class="bi bi-gear"></i> Kelola
                    </a>
                </div>
            </div>
            
            <!-- Menu Database -->
<!-- Menu Database -->
<div class="col-md-4">
    <div class="menu-dev-card">
        <div class="menu-icon" style="background: rgba(102, 126, 234, 0.2); color: #667eea;">
            <i class="bi bi-database"></i>
        </div>
        <h5 class="menu-title">Database Manager</h5>
        <p class="menu-desc">Lihat statistik dan backup database</p>
<a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-primary btn-dev">
    <i class="bi bi-box-arrow-up-right"></i> Buka phpMyAdmin
</a>
    </div>
</div>
            
            
            <!-- Menu Logout -->
            <div class="col-md-4">
                <div class="menu-dev-card">
                    <div class="menu-icon" style="background: rgba(107, 114, 128, 0.2); color: #9ca3af;">
                        <i class="bi bi-box-arrow-right"></i>
                    </div>
                    <h5 class="menu-title">Logout</h5>
                    <p class="menu-desc">Keluar dari sistem</p>
                    <a href="logout.php" class="btn btn-secondary btn-dev">
                        <i class="bi bi-box-arrow-right"></i> Logout
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="text-center mt-5">
            <small class="text-white-50">
                <i class="bi bi-shield-check"></i> Developer Mode - Akses Penuh
            </small>
        </div>
    </div>
</body>
</html>